try:
	from Tkinter import *
	from tkFileDialog import *
	import tkMessageBox
except ImportError:
	from tkinter import *
	from tkinter.filedialog import *
	import tkinter.messagebox as tkMessageBox
import os
import datetime

SOForGenes = ['C_gene_segment', 'gene', 'J_gene_segment', 'lincRNA_gene', 'miRNA_gene', 'mt_gene', 'ncRNA_gene', 'processed_transcript', 'pseudogene', 'RNA', 'rRNA_gene', 'snoRNA_gene', 'snRNA_gene', 'V_gene_segment', 'VD_gene_segment']
SOFormRNA = ['C_gene_segment', 'D_gene_segment', 'J_gene_segment', 'lincRNA', 'lnc_RNA', 'miRNA', 'mRNA', 'ncRNA', 'NMD_transcript_variant', 'processed_pseudogene', 'processed_transcript', 'pseudogene', 'pseudogenic_transcript', 'rRNA', 'scRNA', 'snoRNA', 'snRNA', 'transcript', 'tRNA', 'V_gene_segment', 'vaultRNA_primary_transcript']

UpAndDownAndInter = []
introns = []
exons = []
transcript = []
utr5 = []
utr3 = []
cds = []
types = []
identCurr = ""
identAft = ""

bedUpstream = []
gff3Upstream = []
gff3Upstream.append("##gff-version 3")
gffUpstream = []

bedDownstream = []
gff3Downstream = []
gff3Downstream.append("##gff-version 3")
gffDownstream = []

bedIntergenic = []
gff3Intergenic = []
gff3Intergenic.append("##gff-version 3")
gffIntergenic = []

bedIntrons = []
gff3Introns = []
gff3Introns.append("##gff-version 3")
gffIntrons = []

bedGenes = []
gff3Genes = []
gff3Genes.append("##gff-version 3")
gffGenes = []

bedExons = []
gff3Exons = []
gff3Exons.append("##gff-version 3")
gffExons = []

bedTranscript = []
gff3Transcript = []
gff3Transcript.append("##gff-version 3")
gffTranscript = []

bedUrt5 = []
gff3Urt5 = []
gff3Urt5.append("##gff-version 3")
gffUrt5 = []

bedUrt3 = []
gff3Urt3 = []
gff3Urt3.append("##gff-version 3")
gffUrt3 = []

bedCDS = []
gff3CDS = []
gff3CDS.append("##gff-version 3")
gffCDS = []

def getTypes(fileName):
	global types
	types = []
	openFile = open(fileName, "r+")
	readFile = openFile.read()
	openFile.close()
	splitFile = readFile.split("\n")
	splitFile = list(filter(None, splitFile))
	readFile = ""

	for j in splitFile:
		splitJ = j.split("\t")
		splitJ = list(filter(None, splitJ))
		if len(splitJ) > 8:
			types.append(splitJ[2])
	types = list(set(filter(None, types)))

def zero():
	global UpAndDownAndInter, transcript, introns, exons, utr5, utr3, cds, identCurr, identAft
	UpAndDownAndInter = []
	introns = []
	exons = []
	transcript = []
	utr5 = []
	utr3 = []
	cds = []
	identCurr = ""
	identAft = ""

	bedUpstream = []
	gff3Upstream = []
	gff3Upstream.append("##gff-version 3")
	gffUpstream = []

	bedDownstream = []
	gff3Downstream = []
	gff3Downstream.append("##gff-version 3")
	gffDownstream = []

	bedIntergenic = []
	gff3Intergenic = []
	gff3Intergenic.append("##gff-version 3")
	gffIntergenic = []

	bedIntrons = []
	gff3Introns = []
	gff3Introns.append("##gff-version 3")
	gffIntrons = []

	bedGenes = []
	gff3Genes = []
	gff3Genes.append("##gff-version 3")
	gffGenes = []

	bedExons = []
	gff3Exons = []
	gff3Exons.append("##gff-version 3")
	gffExons = []

	bedTranscript = []
	gff3Transcript = []
	gff3Transcript.append("##gff-version 3")
	gffTranscript = []

	bedUrt5 = []
	gff3Urt5 = []
	gff3Urt5.append("##gff-version 3")
	gffUrt5 = []

	bedUrt3 = []
	gff3Urt3 = []
	gff3Urt3.append("##gff-version 3")
	gffUrt3 = []

	bedCDS = []
	gff3CDS = []
	gff3CDS.append("##gff-version 3")
	gffCDS = []

########################################################################
# upstreamExtraction
########################################################################
def upstreamExtraction(fileName, outputDir, UpAndDownAndInter, upstreamLength, status, sameToIutputFile, bedOutput, fastaOutput):
	bedUpstream = []
	gff3Upstream = []
	gff3Upstream.append("##gff-version 3")
	gffUpstream = []
	seqUpstream = []

	try:
		splitFileName = fileName.split("/")
		splitFileName = list(filter(None, splitFileName))
		OutFilePrefix = "%s/%s" %(outputDir, splitFileName[-1])
	except ImportError:
		splitFileName = fileName.split("\\")
		splitFileName = list(filter(None, splitFileName))
		OutFilePrefix = "%s\%s" %(outputDir, splitFileName[-1])

	openFile = open(fileName, "r+")
	readFile = openFile.read()
	openFile.close()
	splitFile = readFile.split("\n")
	splitFile = list(filter(None, splitFile))
	readFile = ""

	if splitFile[0] == "##gff-version 3":
		gffType = "gff-v3"

	else:
		gffType = "gff-v2"

	if gffType == "gff-v3":

		for i in splitFile:
			splitI = i.split("\t")
			splitI = list(filter(None, splitI))

			if len(splitI) > 8:
				splitI9 = splitI[8].split(";")

				if splitI[2] in SOForGenes and "Parent" not in splitI[8] or splitI[2] == "chromosome":
					UpAndDownAndInter.append(i)

	else:

		for i in splitFile:
			splitI = i.split("\t")
			splitI = list(filter(None, splitI))

			if len(splitI) > 8:

				if splitI[2] in SOForGenes and "transcript_id" not in splitI[8]:
					UpAndDownAndInter.append(i)

	UpAndDownAndInter = list(filter(None, UpAndDownAndInter))
	splitFile = []
	chrStart = ""
	chrEnd = ""

	for mIndex, m in enumerate(UpAndDownAndInter):
		splitM = m.split("\t")
		splitM = list(filter(None, splitM))
		
		if splitM[2] == "chromosome":
			chrStart = int(splitM[3])
			chrEnd = int(splitM[4])
		
		else:
			geneStart = int(splitM[3])
			geneEnd = int(splitM[4])
			splitM9 = splitM[8].split(";")

			if splitM[6] == "+":
				beforeCounter = 1

				while (mIndex-beforeCounter <= len(UpAndDownAndInter) - 1) and (mIndex-beforeCounter >= 0):

					beforeMIndex = UpAndDownAndInter[mIndex-beforeCounter]
					splitBeforeMIndex = beforeMIndex.split("\t")
					splitBeforeMIndex = list(filter(None, splitBeforeMIndex))

					if splitBeforeMIndex[6] == splitM[6] or splitBeforeMIndex[2] == "chromosome":

						if splitBeforeMIndex[2] == "chromosome":
							
							if splitBeforeMIndex[0] == splitM[0]:

								if geneStart == chrStart or geneStart - 1 == chrStart:
									geneUpFrom = str(chrStart)
									geneUpTo = str(geneStart)
								
								else:
									geneUpFrom = str(chrStart)
									geneUpTo = str(geneStart - 1)
							else:
								
								if upstreamLength < geneStart:
									geneUpFrom = str(int(geneStart) - int(upstreamLength) - 1)
									geneUpTo = str(geneStart - 1)
								
								else:
									geneUpFrom = str(1)
									geneUpTo = str(geneStart - 1)

						else:
							
							startBeforeMIndex = int(splitBeforeMIndex[3])
							endBeforeMIndex = int(splitBeforeMIndex[4])
							geneUpFrom = str(endBeforeMIndex + 1)
							geneUpTo = str(geneStart - 1)

						if int(geneUpTo) <= int(geneUpFrom):
							beforeCounter += 1

						else:
							break

					else:
						beforeCounter += 1

				else:
					geneUpFrom = str(geneStart - int(upstreamLength))
					geneUpTo = str(geneStart - 1)

				if int(upstreamLength) < int(geneUpTo) - int(geneUpFrom):
					geneUpFrom = str(int(geneUpTo) - int(upstreamLength))
				
				else:
					
					if status == 1:
						geneUpFrom = str(int(geneUpTo) - int(upstreamLength))
						
						if int(geneUpFrom) < int(upstreamLength):
							geneUpFrom = 1

				bedUpstream.append("%s\t%s\t%s\tupstream %s\t.\t%s" 
				%(splitM[0], geneUpFrom, geneUpTo, splitM9[0], splitM[6]))
				
				if gffType == "gff-v3":
					gff3Upstream.append("%s\t%s\tupstream\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], geneUpFrom, geneUpTo, splitM[6], splitM9[0]))
				
				if gffType == "gff-v2":
					gffUpstream.append("%s\t%s\tupstream\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], geneUpFrom, geneUpTo, splitM[6], splitM9[0]))

			if splitM[6] == "-":
				afterCounter = 1

				while (mIndex+afterCounter <= len(UpAndDownAndInter) - 1) and (mIndex+afterCounter >= 0):
					afterMIndex = UpAndDownAndInter[mIndex + afterCounter]
					splitAfterMIndex = afterMIndex.split("\t")
					splitAfterMIndex = list(filter(None, splitAfterMIndex))
					
					if splitAfterMIndex[6] == splitM[6] or splitAfterMIndex[2] == "chromosome":
						
						if splitAfterMIndex[2] == "chromosome":
							
							if chrEnd:

								if chrEnd == geneEnd or chrEnd == geneEnd - 1:
									geneDownFrom = geneEnd
									geneDownTo = chrEnd
								
								else:
									geneDownFrom = geneEnd + 1
									geneDownTo = chrEnd
							
							else:
								startAfterMIndex = int(splitAfterMIndex[3])
								endAfterMIndex = int(splitAfterMIndex[4])
								geneDownFrom = str(geneEnd + 1)
								geneDownTo = str(startAfterMIndex - 1)
						
						else:
							startAfterMIndex = int(splitAfterMIndex[3])
							endAfterMIndex = int(splitAfterMIndex[4])
							geneDownFrom = str(geneEnd + 1)
							geneDownTo = str(startAfterMIndex - 1)
						
						if int(geneDownTo) <= int(geneDownFrom):
							afterCounter += 1
						
						else:
							break
					
					else:
						afterCounter += 1
				
				else:
					
					if "chromosome" in types:
						
						if chrEnd == geneEnd or chrEnd == geneEnd - 1:
							geneDownFrom = str(geneEnd)
							geneDownTo = str(chrEnd)
						
						else:
							geneDownFrom = str(geneEnd + 1)
							geneDownTo = str(chrEnd)
					
					else:
						geneDownFrom = str(geneEnd + 1)
						geneDownTo = str(int(geneEnd) + 1 + int(upstreamLength))
				
				if int(upstreamLength) < int(geneDownTo) - int(geneDownFrom):
					geneDownTo = str(int(geneDownFrom) + int(upstreamLength))

				else:

					if status == 1:
						geneDownTo = str(int(geneDownFrom) + int(upstreamLength))

						if "chromosome" in types:
							if int(geneDownTo) > chrEnd:
								geneDownTo = chrEnd
				
				bedUpstream.append("%s\t%s\t%s\tupstream %s\t.\t%s" 
				%(splitM[0], geneDownFrom, geneDownTo, splitM9[0], splitM[6]))
				
				if gffType == "gff-v3":
					gff3Upstream.append("%s\t%s\tupstream\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], geneDownFrom, geneDownTo, splitM[6], splitM9[0]))
				
				if gffType == "gff-v2":
					gffUpstream.append("%s\t%s\tupstream\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], geneDownFrom, geneDownTo, splitM[6], splitM9[0]))
	
	if len(UpAndDownAndInter) >= 1:
		UpAndDownAndInter = []
		
		if bedOutput == 1:
			writeFile = open(OutFilePrefix+".UpstreamOnly.bed", "w+")
			writeFile.write("\n".join(bedUpstream))
			writeFile.close()
			
		if gffType == "gff-v3" and sameToIutputFile == 1:
			writeFile = open(OutFilePrefix+".UpstreamOnly.gff3", "w+")
			writeFile.write("\n".join(gff3Upstream))
			writeFile.close()
			gff3Upstream = []
			gff3Upstream.append("##gff-version 3")
			
		if gffType == "gff-v2" and sameToIutputFile == 1:
			writeFile = open(OutFilePrefix+".UpstreamOnly.gtf", "w+")
			writeFile.write("\n".join(gffUpstream))
			writeFile.close()
			gffUpstream = []
			
		if fastaOutput == 1 and fastaSingleInput[0] == 1:
			readFasta(fastaFile=fastaSingleInput[1], bedFile=bedUpstream, suffix="UpstreamOnly")
		
		if fastaOutput == 1 and fastaMultiInput[0] == 1:
			readFasta(fastaFile=multiFastaOutput, bedFile=bedUpstream, suffix="UpstreamOnly")
		
		print("%s Upstream genes extracted successfully from %s" %(datetime.datetime.now(), ".".join(splitFileName[-1].split(".")[:-1])))

	bedUpstream = []
	gff3Upstream = []
	gff3Upstream.append("##gff-version 3")
	gffUpstream = []
	
########################################################################
# downstreamExtraction
########################################################################
def downstreamExtraction(fileName, outputDir, UpAndDownAndInter, downstreamLength, status, sameToIutputFile, bedOutput, fastaOutput):
	bedDownstream = []
	gff3Downstream = []
	gff3Downstream.append("##gff-version 3")
	gffDownstream = []

	try:
		splitFileName = fileName.split("/")
		splitFileName = list(filter(None, splitFileName))
		OutFilePrefix = "%s/%s" %(outputDir, splitFileName[-1])
	except ImportError:
		splitFileName = fileName.split("\\")
		splitFileName = list(filter(None, splitFileName))
		OutFilePrefix = "%s\%s" %(outputDir, splitFileName[-1])

	openFile = open(fileName, "r+")
	readFile = openFile.read()
	openFile.close()
	splitFile = readFile.split("\n")
	splitFile = list(filter(None, splitFile))
	readFile = ""

	if splitFile[0] == "##gff-version 3":
		gffType = "gff-v3"

	else:
		gffType = "gff-v2"

	if gffType == "gff-v3":

		for i in splitFile:
			splitI = i.split("\t")
			splitI = list(filter(None, splitI))

			if len(splitI) > 8:
				splitI9 = splitI[8].split(";")

				if splitI[2] in SOForGenes and "Parent" not in splitI[8] or splitI[2] == "chromosome":
					UpAndDownAndInter.append(i)

	else:

		for i in splitFile:
			splitI = i.split("\t")
			splitI = list(filter(None, splitI))

			if len(splitI) > 8:

				if splitI[2] in SOForGenes and "transcript_id" not in splitI[8]:
					UpAndDownAndInter.append(i)

	UpAndDownAndInter = list(filter(None, UpAndDownAndInter))
	splitFile = []
	chrStart = ""
	chrEnd = ""

	for mIndex, m in enumerate(UpAndDownAndInter):
		splitM = m.split("\t")
		splitM = list(filter(None, splitM))
		
		if splitM[2] == "chromosome":
			chrStart = int(splitM[3])
			chrEnd = int(splitM[4])
		
		else:
			geneStart = int(splitM[3])
			geneEnd = int(splitM[4])
			splitM9 = splitM[8].split(";")
			
			if splitM[6] == "-":
				beforeCounter = 1
				
				while (mIndex-beforeCounter <= len(UpAndDownAndInter) - 1) and (mIndex-beforeCounter >= 0):
					beforeMIndex = UpAndDownAndInter[mIndex-beforeCounter]
					splitBeforeMIndex = beforeMIndex.split("\t")
					splitBeforeMIndex = list(filter(None, splitBeforeMIndex))
					
					if splitBeforeMIndex[6] == splitM[6] or splitBeforeMIndex[2] == "chromosome":

						if splitBeforeMIndex[2] == "chromosome":
							
							if splitBeforeMIndex[0] == splitM[0]:

								if geneStart == chrStart or geneStart - 1 == chrStart:
									geneUpFrom = str(chrStart)
									geneUpTo = str(geneStart)
								
								else:
									geneUpFrom = str(chrStart)
									geneUpTo = str(geneStart - 1)
							else:
								
								if downstreamLength < geneStart:
									geneUpFrom = str(int(geneStart) - int(downstreamLength) - 1)
									geneUpTo = str(geneStart - 1)
								
								else:
									geneUpFrom = str(1)
									geneUpTo = str(geneStart - 1)
						
						else:
							startBeforeMIndex = int(splitBeforeMIndex[3])
							endBeforeMIndex = int(splitBeforeMIndex[4])
							geneUpFrom = str(endBeforeMIndex + 1)
							geneUpTo = str(geneStart - 1)
						
						if int(geneUpTo) <= int(geneUpFrom):
							beforeCounter += 1
						
						else:
							break
					
					else:
						beforeCounter += 1
				
				else:
					geneUpFrom = str((geneStart - 1) - int(downstreamLength))
					geneUpTo = str(geneStart - 1)
				
				if int(downstreamLength) < int(geneUpTo) - int(geneUpFrom):
					geneUpFrom = str(int(geneUpTo) - int(downstreamLength))
				
				else:
					
					if status == 1:
						geneUpFrom = str(int(geneUpTo) - int(downstreamLength))
						
						if int(geneUpFrom) < int(downstreamLength):
							geneUpFrom = 1
				
				bedDownstream.append("%s\t%s\t%s\tdownstream %s\t.\t%s" 
				%(splitM[0], geneUpFrom, geneUpTo, splitM9[0], splitM[6]))

				if gffType == "gff-v3":
					gff3Downstream.append("%s\t%s\tdownstream\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], geneUpFrom, geneUpTo, splitM[6], splitM9[0]))
				
				if gffType == "gff-v2":
					gffDownstream.append("%s\t%s\tdownstream\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], geneUpFrom, geneUpTo, splitM[6], splitM9[0]))

			
			if splitM[6] == "+":
				afterCounter = 1
				
				while (mIndex+afterCounter <= len(UpAndDownAndInter) - 1) and (mIndex+afterCounter >= 0):
					afterMIndex = UpAndDownAndInter[mIndex + afterCounter]
					splitAfterMIndex = afterMIndex.split("\t")
					splitAfterMIndex = list(filter(None, splitAfterMIndex))
					
					if splitAfterMIndex[6] == splitM[6] or splitAfterMIndex[2] == "chromosome":
						
						if splitAfterMIndex[2] == "chromosome":
							
							if chrEnd:

								if chrEnd == geneEnd or chrEnd == geneEnd - 1:
									geneDownFrom = geneEnd
									geneDownTo = chrEnd
								
								else:
									geneDownFrom = geneEnd + 1
									geneDownTo = chrEnd
							
							else:
								startAfterMIndex = int(splitAfterMIndex[3])
								endAfterMIndex = int(splitAfterMIndex[4])
								geneDownFrom = str(geneEnd + 1)
								geneDownTo = str(startAfterMIndex - 1)
						
						else:
							startAfterMIndex = int(splitAfterMIndex[3])
							endAfterMIndex = int(splitAfterMIndex[4])
							geneDownFrom = str(geneEnd + 1)
							geneDownTo = str(startAfterMIndex - 1)
						
						if int(geneDownTo) <= int(geneDownFrom):
							afterCounter += 1
						
						else:
							break
					
					else:
						afterCounter += 1
				
				else:
					
					if "chromosome" in types:
						
						if chrEnd == geneEnd or chrEnd == geneEnd - 1:
							geneDownFrom = str(geneEnd)
							geneDownTo = str(chrEnd)
						
						else:
							geneDownFrom = str(geneEnd + 1)
							geneDownTo = str(chrEnd)
					
					else:
						geneDownFrom = str(geneEnd + 1)
						geneDownTo = str(int(geneEnd) + 1 + int(downstreamLength))
				
				if int(downstreamLength) < int(geneDownTo) - int(geneDownFrom):
					geneDownTo = str(int(geneDownFrom) + int(downstreamLength))

				else:

					if status == 1:
						geneDownTo = str(int(geneDownFrom) + int(downstreamLength))

						if "chromosome" in types:
							if int(geneDownTo) > chrEnd:
								geneDownTo = chrEnd
				
				bedDownstream.append("%s\t%s\t%s\tdownstream %s\t.\t%s" 
				%(splitM[0], geneDownFrom, geneDownTo, splitM9[0], splitM[6]))

				if gffType == "gff-v3":
					gff3Downstream.append("%s\t%s\tdownstream\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], geneDownFrom, geneDownTo, splitM[6], splitM9[0]))
				
				if gffType == "gff-v2":
					gffDownstream.append("%s\t%s\tdownstream\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], geneDownFrom, geneDownTo, splitM[6], splitM9[0]))

	if len(UpAndDownAndInter) >= 1:
		UpAndDownAndInter = []

		if bedOutput == 1:
			writeFile = open(OutFilePrefix+".DownstreamOnly.bed", "w+")
			writeFile.write("\n".join(bedDownstream))
			writeFile.close()

		if gffType == "gff-v3" and sameToIutputFile == 1:
			writeFile = open(OutFilePrefix+".DownstreamOnly.gff3", "w+")
			writeFile.write("\n".join(gff3Downstream))
			writeFile.close()
			gff3Downstream = []
			gff3Downstream.append("##gff-version 3")
		
		if gffType == "gff-v2" and sameToIutputFile == 1:
			writeFile = open(OutFilePrefix+".DownstreamOnly.gtf", "w+")
			writeFile.write("\n".join(gffDownstream))
			writeFile.close()
			gffDownstream = []

		if fastaOutput == 1 and fastaSingleInput[0] == 1:
			readFasta(fastaFile=fastaSingleInput[1], bedFile=bedDownstream, suffix="DownstreamOnly")
		
		if fastaOutput == 1 and fastaMultiInput[0] == 1:
			readFasta(fastaFile=multiFastaOutput, bedFile=bedDownstream, suffix="DownstreamOnly")
		
		print("%s Downstream genes extracted successfully from %s" %(datetime.datetime.now(), ".".join(splitFileName[-1].split(".")[:-1])))
	
	bedDownstream = []
	gff3Downstream = []
	gff3Downstream.append("##gff-version 3")
	gffDownstream = []

########################################################################
# intergenicExtraction
########################################################################
def intergenicExtraction(fileName, outputDir, UpAndDownAndInter, sameToIutputFile, bedOutput, fastaOutput):
	forSort = 0
	bedIntergenic = []
	gff3Intergenic = []
	gff3Intergenic.append("##gff-version 3")
	gffIntergenic = []

	try:
		splitFileName = fileName.split("/")
		splitFileName = list(filter(None, splitFileName))
		OutFilePrefix = "%s/%s" %(outputDir, splitFileName[-1])
	except ImportError:
		splitFileName = fileName.split("\\")
		splitFileName = list(filter(None, splitFileName))
		OutFilePrefix = "%s\%s" %(outputDir, splitFileName[-1])

	openFile = open(fileName, "r+")
	readFile = openFile.read()
	openFile.close()
	splitFile = readFile.split("\n")
	splitFile = list(filter(None, splitFile))
	readFile = ""

	if splitFile[0] == "##gff-version 3":
		gffType = "gff-v3"

	else:
		gffType = "gff-v2"

	if gffType == "gff-v3":

		for i in splitFile:
			splitI = i.split("\t")
			splitI = list(filter(None, splitI))

			if len(splitI) > 8:
				splitI9 = splitI[8].split(";")

				if splitI[2] in SOForGenes and "Parent" not in splitI[8] or splitI[2] == "chromosome":
					UpAndDownAndInter.append(i)

	else:

		for i in splitFile:
			splitI = i.split("\t")
			splitI = list(filter(None, splitI))

			if len(splitI) > 8:

				if splitI[2] in SOForGenes and "transcript_id" not in splitI[8]:
					UpAndDownAndInter.append(i)

	UpAndDownAndInter = list(filter(None, UpAndDownAndInter))
	splitFile = []
	chrStart = ""
	chrEnd = ""

	for mIndex, m in enumerate(UpAndDownAndInter):
		splitM = m.split("\t")
		splitM = list(filter(None, splitM))
		
		if splitM[2] == "chromosome":
			chrName = splitM[0]
			chrType = splitM[2]
			chrStart = int(splitM[3])
			chrEnd = int(splitM[4])
			chrID = splitM[8].split(";")[0]
		
		else:
			geneStart = int(splitM[3])
			geneEnd = int(splitM[4])
			splitM9 = splitM[8].split(";")
			
			if splitM[6] == "-" or splitM[6] == "+":
				fileEnd = 0
				beforeCounter = 1
				
				while (mIndex-beforeCounter <= len(UpAndDownAndInter) - 1) and (mIndex-beforeCounter >= 0):
					beforeMIndex = UpAndDownAndInter[mIndex-beforeCounter]
					splitBeforeMIndex = beforeMIndex.split("\t")
					splitBeforeMIndex = list(filter(None, splitBeforeMIndex))
					splitBeforeMIndex9 = splitBeforeMIndex[8].split(";")
					
					if splitBeforeMIndex[6] == splitM[6] or splitBeforeMIndex[2] == "chromosome":
						
						if splitBeforeMIndex[2] == "chromosome":
							
							if splitBeforeMIndex[0] == splitM[0]:

								if geneStart == chrStart or geneStart - 1 == chrStart:
									geneUpFrom = str(chrStart)
									geneUpTo = str(geneStart)
								
								else:
									geneUpFrom = str(chrStart)
									geneUpTo = str(geneStart - 1)
							else:
								
								geneUpFrom = str(1)
								geneUpTo = str(geneStart - 1)
						
						else:
							startBeforeMIndex = int(splitBeforeMIndex[3])
							endBeforeMIndex = int(splitBeforeMIndex[4])
							geneUpFrom = str(endBeforeMIndex + 1)
							geneUpTo = str(geneStart - 1)
						
						if int(geneUpTo) <= int(geneUpFrom):
							beforeCounter += 1
						
						else:
							break
					
					else:
						beforeCounter += 1
				
				else:
					continue
				
				upIn = "%s\t%s\t%s\tintergenic %s : %s\t.\t%s" %(splitM[0], geneUpFrom, geneUpTo, splitBeforeMIndex9[0], splitM9[0], splitM[6])
				
				if upIn in bedIntergenic:
					pass
				
				else:
					bedIntergenic.append(upIn)
					
					if gffType == "gff-v3":
						gff3Intergenic.append("%s\t%s\tintergenic\t%s\t%s\t.\t%s\t.\t%s;%s" %(splitM[0], splitM[1], geneUpFrom, geneUpTo, splitM[6], splitBeforeMIndex9[0], splitM9[0]))
				
					if gffType == "gff-v2":
						gffIntergenic.append("%s\t%s\tintergenic\t%s\t%s\t.\t%s\t.\t%s; %s" %(splitM[0], splitM[1], geneUpFrom, geneUpTo, splitM[6], splitBeforeMIndex9[0], splitM9[0]))


			
			if splitM[6] == "-" or splitM[6] == "+":
				fileEnd = 0
				afterCounter = 1
				
				while (mIndex+afterCounter <= len(UpAndDownAndInter) - 1) and (mIndex+afterCounter >= 0):
					afterMIndex = UpAndDownAndInter[mIndex + afterCounter]
					splitAfterMIndex = afterMIndex.split("\t")
					splitAfterMIndex = list(filter(None, splitAfterMIndex))
					splitAfterMIndex9 = splitAfterMIndex[8].split(";")
					
					if splitAfterMIndex[6] == splitM[6] or splitAfterMIndex[2] == "chromosome":
						
						if splitAfterMIndex[2] == "chromosome":
							
							if chrEnd:

								if chrEnd == geneEnd or chrEnd == geneEnd - 1:
									geneDownFrom = geneEnd
									geneDownTo = chrEnd
								
								else:
									geneDownFrom = geneEnd + 1
									geneDownTo = chrEnd
							
							else:
								startAfterMIndex = int(splitAfterMIndex[3])
								endAfterMIndex = int(splitAfterMIndex[4])
								geneDownFrom = str(geneEnd + 1)
								geneDownTo = str(startAfterMIndex - 1)
						
						else:
							startAfterMIndex = int(splitAfterMIndex[3])
							endAfterMIndex = int(splitAfterMIndex[4])
							geneDownFrom = str(geneEnd + 1)
							geneDownTo = str(startAfterMIndex - 1)
						
						if int(geneDownTo) <= int(geneDownFrom):
							afterCounter += 1
						
						else:
							break
					
					else:
						afterCounter += 1
				
				else:
					if "chromosome" in types:
						
						if chrEnd == geneEnd or chrEnd == geneEnd - 1:
							geneDownFrom = str(geneEnd)
							geneDownTo = str(chrEnd)
						
						else:
							geneDownFrom = str(geneEnd + 1)
							geneDownTo = str(chrEnd)
						
						fileEnd = 1
					
					else:
						continue
				
				if splitAfterMIndex[2] == "chromosome" or fileEnd == 1:
					downIn = "%s\t%s\t%s\tintergenic %s : %s\t.\t%s" %(splitM[0], geneDownFrom, geneDownTo, splitM9[0], chrID, splitM[6])
					
					if downIn in bedIntergenic:
						pass
					
					else:
						bedIntergenic.append(downIn)

						if gffType == "gff-v3":
							gff3Intergenic.append("%s\t%s\tintergenic\t%s\t%s\t.\t%s\t.\t%s;%s" %(splitM[0], splitM[1], geneDownFrom, geneDownTo, splitM[6], splitM9[0], chrID))
				
						if gffType == "gff-v2":
							gffIntergenic.append("%s\t%s\tintergenic\t%s\t%s\t.\t%s\t.\t%s; %s" %(splitM[0], splitM[1], geneDownFrom, geneDownTo, splitM[6], splitM9[0], chrID))
				
				else:
					downIn = "%s\t%s\t%s\tintergenic %s : %s\t.\t%s" %(splitM[0], geneDownFrom, geneDownTo, splitM9[0], splitAfterMIndex9[0], splitM[6])
					
					if downIn in bedIntergenic:
						pass
					
					else:
						bedIntergenic.append(downIn)

						if gffType == "gff-v3":
							gff3Intergenic.append("%s\t%s\tintergenic\t%s\t%s\t.\t%s\t.\t%s;%s" %(splitM[0], splitM[1], geneDownFrom, geneDownTo, splitM[6], splitM9[0], splitAfterMIndex9[0]))
				
						if gffType == "gff-v2":
							gffIntergenic.append("%s\t%s\tintergenic\t%s\t%s\t.\t%s\t.\t%s; %s" %(splitM[0], splitM[1], geneDownFrom, geneDownTo, splitM[6], splitM9[0], splitAfterMIndex9[0]))
	
	if len(UpAndDownAndInter) >= 1:
		UpAndDownAndInter = []

		if bedOutput == 1:
			writeFile = open(OutFilePrefix+".IntergenicOnly.bed", "w+")
			writeFile.write("\n".join(bedIntergenic))
			writeFile.close()

		if gffType == "gff-v3" and sameToIutputFile == 1:
			writeFile = open(OutFilePrefix+".IntergenicOnly.gff3", "w+")
			writeFile.write("\n".join(gff3Intergenic))
			writeFile.close()
			gff3Intergenic = []
			gff3Intergenic.append("##gff-version 3")
		
		if gffType == "gff-v2" and sameToIutputFile == 1:
			writeFile = open(OutFilePrefix+".IntergenicOnly.gtf", "w+")
			writeFile.write("\n".join(gffIntergenic))
			writeFile.close()
			gffIntergenic = []

		if fastaOutput == 1 and fastaSingleInput[0] == 1:
			readFasta(fastaFile=fastaSingleInput[1], bedFile=bedIntergenic, suffix="IntergenicOnly")

		if fastaOutput == 1 and fastaMultiInput[0] == 1:
			readFasta(fastaFile=multiFastaOutput, bedFile=bedIntergenic, suffix="IntergenicOnly")
		
		print("%s Intergenic regions extracted successfully from %s" %(datetime.datetime.now(), ".".join(splitFileName[-1].split(".")[:-1])))
	
	bedIntergenic = []
	gff3Intergenic = []
	gff3Intergenic.append("##gff-version 3")
	gffIntergenic = []

########################################################################
# intronsExtraction
########################################################################
def intronsExtraction(fileName, outputDir, introns, sameToIutputFile, bedOutput, fastaOutput):
	EOF = 0
	bedIntrons = []
	gff3Introns = []
	gff3Introns.append("##gff-version 3")
	gffIntrons = []

	try:
		splitFileName = fileName.split("/")
		splitFileName = list(filter(None, splitFileName))
		OutFilePrefix = "%s/%s" %(outputDir, splitFileName[-1])
	except ImportError:
		splitFileName = fileName.split("\\")
		splitFileName = list(filter(None, splitFileName))
		OutFilePrefix = "%s\%s" %(outputDir, splitFileName[-1])

	openFile = open(fileName, "r+")
	readFile = openFile.read()
	openFile.close()
	splitFile = readFile.split("\n")
	splitFile = list(filter(None, splitFile))
	readFile = ""

	if splitFile[0] == "##gff-version 3":
		gffType = "gff-v3"

	else:
		gffType = "gff-v2"

	if gffType == "gff-v3":

		for i in splitFile:
			splitI = i.split("\t")
			splitI = list(filter(None, splitI))

			if "intron" in types:
				if len(splitI) > 8:
					if splitI[2] in SOFormRNA and "Parent" in splitI[8] or "intron" in splitI[2]:
						introns.append(i)

			else:
				if len(splitI) > 8:
					if splitI[2] in SOFormRNA and "Parent" in splitI[8] or "exon" in splitI[2]:
						introns.append(i)

	else:

		for i in splitFile:
			splitI = i.split("\t")
			splitI = list(filter(None, splitI))

			if "intron" in types:
				if len(splitI) > 8:
					if splitI[2] in SOFormRNA and "transcript_id" in splitI[8] or "intron" in splitI[2]:
						introns.append(i)

			else:
				if len(splitI) > 8:
					if splitI[2] in SOFormRNA and "transcript_id" in splitI[8] or "exon" in splitI[2]:
						introns.append(i)

	introns = list(filter(None, introns))
	splitFile = []

	if "intron" not in types:

		if gffType == "gff-v3":
			
			for mIndex, m in enumerate(introns):
				splitM = m.split("\t")
				splitM = list(filter(None, splitM))
				splitM9 = splitM[8].split(";")
				
				if splitM[2] in SOFormRNA and "Parent" in splitM[8]:
					transcriptStart = int(splitM[3])
					transcriptEnd = int(splitM[4])
					counter = 0
				
				elif "exon" in splitM[2]:
					exonStart = int(splitM[3])
					exonEnd = int(splitM[4])
					
					if exonStart >= transcriptStart and exonEnd <= transcriptEnd:
						afterCounter = 1
						
						if (mIndex + afterCounter <= len(introns)-1) and (mIndex+afterCounter >= 0):
							afterMIndex = introns[mIndex + afterCounter]
							splitAfterMIndex = afterMIndex.split("\t")
							splitAfterMIndex = list(filter(None, splitAfterMIndex))
							splitAfterMIndex9 = splitAfterMIndex[8].split(";")
							
							if splitAfterMIndex[2] == splitM[2] or splitAfterMIndex[2] in SOFormRNA and "Parent" in splitM[8]:
								
								if splitAfterMIndex[2] in SOFormRNA and "Parent" in splitM[8]:
									continue
								
								else:
									startAfterMIndex = int(splitAfterMIndex[3])
									endAfterMIndex = int(splitAfterMIndex[4])
									intronDownFrom = str(exonEnd + 1)
									intronDownTo = str(startAfterMIndex - 1)
								
									if int(intronDownTo) < int(intronDownFrom):
										startAfterMIndex = int(splitAfterMIndex[3])
										endAfterMIndex = int(splitAfterMIndex[4])
										intronDownFrom = str(endAfterMIndex + 1)
										intronDownTo = str(exonStart - 1)
						
						else:
							EOF = 1
						
						if len(splitM9) > 3 and len(splitAfterMIndex9) > 3:
							identCurr = "%s;%s;%s" %(splitM9[0], splitM9[1], splitM9[2])
							identAft = "%s;%s;%s" %(splitAfterMIndex9[0], splitAfterMIndex9[1], splitAfterMIndex9[2])
						
						else:
							identCurr = splitM9[0]
							identAft = splitAfterMIndex9[0]

						if EOF != 1:
							bedIntrons.append("%s\t%s\t%s\tintron %s : %s\t.\t%s" 
							%(splitM[0], intronDownFrom, intronDownTo, identCurr, identAft, splitM[6]))

							if gffType == "gff-v3":
								gff3Introns.append("%s\t%s\tintron\t%s\t%s\t.\t%s\t.\t%s:%s" %(splitM[0], splitM[1], intronDownFrom, intronDownTo, splitM[6], identCurr, identAft))

		else:
			
			for mIndex, m in enumerate(introns):
				splitM = m.split("\t")
				splitM = list(filter(None, splitM))
				splitM9 = splitM[8].split(";")
				
				if splitM[2] in SOFormRNA and "transcript_id" in splitM[8]:
					transcriptStart = int(splitM[3])
					transcriptEnd = int(splitM[4])
				
				elif splitM[2] == "exon":
					exonStart = int(splitM[3])
					exonEnd = int(splitM[4])
					
					if exonStart >= transcriptStart and exonEnd <= transcriptEnd:
						afterCounter = 1
						
						if (mIndex + afterCounter <= len(introns)-1) and (mIndex+afterCounter >= 0):
							afterMIndex = introns[mIndex + afterCounter]
							splitAfterMIndex = afterMIndex.split("\t")
							splitAfterMIndex = list(filter(None, splitAfterMIndex))
							splitAfterMIndex9 = splitAfterMIndex[8].split(";")
							
							if splitAfterMIndex[2] == splitM[2] or splitAfterMIndex[2] in SOFormRNA and "transcript_id" in splitM[8]:
								
								if splitAfterMIndex[2] in SOFormRNA and "transcript_id" in splitM[8]:
									continue
								
								else:
									
									if splitM[6] == "-":
										startAfterMIndex = int(splitAfterMIndex[3])
										endAfterMIndex = int(splitAfterMIndex[4])
										intronDownFrom = str(endAfterMIndex + 1)
										intronDownTo = str(exonStart - 1)
										
										if int(intronDownTo) < int(intronDownFrom):
											startAfterMIndex = int(splitAfterMIndex[3])
											endAfterMIndex = int(splitAfterMIndex[4])
											intronDownFrom = str(exonEnd + 1)
											intronDownTo = str(startAfterMIndex - 1)
									
									elif splitM[6] == "+":
										startAfterMIndex = int(splitAfterMIndex[3])
										endAfterMIndex = int(splitAfterMIndex[4])
										intronDownFrom = str(exonEnd + 1)
										intronDownTo = str(startAfterMIndex - 1)
								
						else:
							EOF = 1
						
						if len(splitM9) > 3 and len(splitAfterMIndex9) > 3:
							identCurr = "%s;%s;%s" %(splitM9[0], splitM9[1], splitM9[2])
							identAft = "%s;%s;%s" %(splitAfterMIndex9[0], splitAfterMIndex9[1], splitAfterMIndex9[2])
						else:
							identCurr = splitM9[0]
							identAft = splitAfterMIndex9[0]
						
						if EOF != 1:
							bedIntrons.append("%s\t%s\t%s\tintron %s : %s\t.\t%s" 
							%(splitM[0], intronDownFrom, intronDownTo, identCurr, identAft, splitM[6]))

							if gffType == "gff-v2":
								gffIntrons.append("%s\t%s\tintron\t%s\t%s\t.\t%s\t.\t%s: %s" %(splitM[0], splitM[1], intronDownFrom, intronDownTo, splitM[6], identCurr, identAft))
	
	else:

		if gffType == "gff-v3":
			
			for mIndex, m in enumerate(introns):
				splitM = m.split("\t")
				splitM = list(filter(None, splitM))
				splitM9 = splitM[8].split(";")
				
				if len(splitM9) > 3:
					identCurr = "%s;%s;%s" %(splitM9[0], splitM9[1], splitM9[2])
				
				else:
					identCurr = splitM9[0]
				
				bedIntrons.append("%s\t%s\t%s\t%s %s\t.\t%s"
				%(splitM[0], splitM[3], splitM[4], splitM[2], identCurr, splitM[6]))

				if gffType == "gff-v3":
					gff3Introns.append("%s\t%s\t%s\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], splitM[2], splitM[3], splitM[4], splitM[6], identCurr))
		
		else:
			
			for mIndex, m in enumerate(introns):
				splitM = m.split("\t")
				splitM = list(filter(None, splitM))
				splitM9 = splitM[8].split(";")
				
				if len(splitM9) > 3:
					identCurr = "%s;%s;%s" %(splitM9[0], splitM9[1], splitM9[2])
				
				else:
					identCurr = splitM9[0]

				bedIntrons.append("%s\t%s\t%s\t%s %s\t.\t%s"
				%(splitM[0], splitM[3], splitM[4], splitM[2], identCurr, splitM[6]))

				if gffType == "gff-v2":
					gffIntrons.append("%s\t%s\t%s\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], splitM[2], splitM[3], splitM[4], splitM[6], identCurr))

	if len(introns) >= 1 :
		introns = []
		if bedOutput == 1:
			writeFile = open(OutFilePrefix+".IntronsOnly.bed", "w+")
			writeFile.write("\n".join(bedIntrons))
			writeFile.close()

		if gffType == "gff-v3" and sameToIutputFile == 1:
			writeFile = open(OutFilePrefix+".IntronsOnly.gff3", "w+")
			writeFile.write("\n".join(gff3Introns))
			writeFile.close()
			gff3Introns = []
			gff3Introns.append("##gff-version 3")
		
		if gffType == "gff-v2" and sameToIutputFile == 1:
			writeFile = open(OutFilePrefix+".IntronsOnly.gtf", "w+")
			writeFile.write("\n".join(gffIntrons))
			writeFile.close()
			gffIntrons = []

		if fastaOutput == 1 and fastaSingleInput[0] == 1:
			readFasta(fastaFile=fastaSingleInput[1], bedFile=bedIntrons, suffix="IntronsOnly")
		
		if fastaOutput == 1 and fastaMultiInput[0] == 1:
			readFasta(fastaFile=multiFastaOutput, bedFile=bedIntrons, suffix="IntronsOnly")
		
		print("%s Introns extracted successfully from %s" %(datetime.datetime.now(), ".".join(splitFileName[-1].split(".")[:-1])))
	
	bedIntrons = []
	gff3Introns = []
	gff3Introns.append("##gff-version 3")
	gffIntrons = []

########################################################################
# genesExtraction
########################################################################
def genesExtraction(fileName, outputDir, UpAndDownAndInter, sameToIutputFile, bedOutput, fastaOutput):
	bedGenes = []
	gff3Genes = []
	gff3Genes.append("##gff-version 3")
	gffGenes = []

	try:
		splitFileName = fileName.split("/")
		splitFileName = list(filter(None, splitFileName))
		OutFilePrefix = "%s/%s" %(outputDir, splitFileName[-1])
	except ImportError:
		splitFileName = fileName.split("\\")
		splitFileName = list(filter(None, splitFileName))
		OutFilePrefix = "%s\%s" %(outputDir, splitFileName[-1])

	openFile = open(fileName, "r+")
	readFile = openFile.read()
	openFile.close()
	splitFile = readFile.split("\n")
	splitFile = list(filter(None, splitFile))
	readFile = ""

	if splitFile[0] == "##gff-version 3":
		gffType = "gff-v3"

	else:
		gffType = "gff-v2"

	if gffType == "gff-v3":

		for i in splitFile:
			splitI = i.split("\t")
			splitI = list(filter(None, splitI))

			if len(splitI) > 8:
				splitI9 = splitI[8].split(";")

				if splitI[2] in SOForGenes and "Parent" not in splitI[8]:
					UpAndDownAndInter.append(i)

	else:

		for i in splitFile:
			splitI = i.split("\t")
			splitI = list(filter(None, splitI))

			if len(splitI) > 8:

				if splitI[2] in SOForGenes and "transcript_id" not in splitI[8]:
					UpAndDownAndInter.append(i)

	UpAndDownAndInter = list(filter(None, UpAndDownAndInter))
	splitFile = []

	if gffType == "gff-v3":
		
		for mIndex, m in enumerate(UpAndDownAndInter):
			splitM = m.split("\t")
			splitM = list(filter(None, splitM))
			splitM9 = splitM[8].split(";")

			if len(splitM9) > 2:
				identCurr = "%s;%s" %(splitM9[0], splitM9[1])
				
			else:
				identCurr = splitM9[0]

			bedGenes.append("%s\t%s\t%s\t%s %s\t.\t%s"
			%(splitM[0], splitM[3], splitM[4], splitM[2], identCurr, splitM[6]))

			if gffType == "gff-v3":
				gff3Genes.append("%s\t%s\t%s\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], splitM[2], splitM[3], splitM[4], splitM[6], identCurr))
	
	else:
		
		for mIndex, m in enumerate(UpAndDownAndInter):
			splitM = m.split("\t")
			splitM = list(filter(None, splitM))
			splitM9 = splitM[8].split(";")

			if len(splitM9) > 2:
				identCurr = "%s;%s" %(splitM9[0], splitM9[1])
				
			else:
				identCurr = splitM9[0]

			bedGenes.append("%s\t%s\t%s\t%s %s\t.\t%s"
			%(splitM[0], splitM[3], splitM[4], splitM[2], identCurr, splitM[6]))

			if gffType == "gff-v2":
				gffGenes.append("%s\t%s\t%s\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], splitM[2], splitM[3], splitM[4], splitM[6], identCurr))
	
	if len(UpAndDownAndInter) >= 1:
		UpAndDownAndInter = []
		if bedOutput == 1:
			writeFile = open(OutFilePrefix+".GenesOnly.bed", "w+")
			writeFile.write("\n".join(bedGenes))
			writeFile.close()
		
		if gffType == "gff-v3" and sameToIutputFile == 1:
			writeFile = open(OutFilePrefix+".GenesOnly.gff3", "w+")
			writeFile.write("\n".join(gff3Genes))
			writeFile.close()
			gff3Genes = []
			gff3Genes.append("##gff-version 3")
		
		if gffType == "gff-v2" and sameToIutputFile == 1:
			writeFile = open(OutFilePrefix+".GenesOnly.gtf", "w+")
			writeFile.write("\n".join(gffGenes))
			writeFile.close()
			gffGenes = []
		
		if fastaOutput == 1 and fastaSingleInput[0] == 1:
			readFasta(fastaFile=fastaSingleInput[1], bedFile=bedGenes, suffix="GenesOnly")
		
		if fastaOutput == 1 and fastaMultiInput[0] == 1:
			readFasta(fastaFile=multiFastaOutput, bedFile=bedGenes, suffix="GenesOnly")
		
		print("%s Genes extracted successfully from %s" %(datetime.datetime.now(), ".".join(splitFileName[-1].split(".")[:-1])))
	
	bedGenes = []
	gff3Genes = []
	gff3Genes.append("##gff-version 3")
	gffGenes = []

########################################################################
# exonsExtraction
########################################################################
def exonsExtraction(fileName, outputDir, exons, sameToIutputFile, bedOutput, fastaOutput):
	bedExons = []
	gff3Exons = []
	gff3Exons.append("##gff-version 3")
	gffExons = []

	try:
		splitFileName = fileName.split("/")
		splitFileName = list(filter(None, splitFileName))
		OutFilePrefix = "%s/%s" %(outputDir, splitFileName[-1])
	except ImportError:
		splitFileName = fileName.split("\\")
		splitFileName = list(filter(None, splitFileName))
		OutFilePrefix = "%s\%s" %(outputDir, splitFileName[-1])

	openFile = open(fileName, "r+")
	readFile = openFile.read()
	openFile.close()
	splitFile = readFile.split("\n")
	splitFile = list(filter(None, splitFile))
	readFile = ""

	if splitFile[0] == "##gff-version 3":
		gffType = "gff-v3"

	else:
		gffType = "gff-v2"

	if gffType == "gff-v3":

		for i in splitFile:
			splitI = i.split("\t")
			splitI = list(filter(None, splitI))

			if len(splitI) > 8:
				splitI9 = splitI[8].split(";")

				if "exon" in splitI[2]:
					exons.append(i)

	else:

		for i in splitFile:
			splitI = i.split("\t")
			splitI = list(filter(None, splitI))

			if len(splitI) > 8:

				if "exon" in splitI[2]:
					exons.append(i)

	exons = list(filter(None, exons))
	splitFile = []

	if gffType == "gff-v3":
		
		for mIndex, m in enumerate(exons):
			splitM = m.split("\t")
			splitM = list(filter(None, splitM))
			splitM9 = splitM[8].split(";")

			if len(splitM9) > 3:
				identCurr = "%s;%s;%s" %(splitM9[0], splitM9[1], splitM9[2])
				
			else:
				identCurr = splitM9[0]

			bedExons.append("%s\t%s\t%s\t%s %s\t.\t%s"
			%(splitM[0], splitM[3], splitM[4], splitM[2], identCurr, splitM[6]))

			if gffType == "gff-v3":
				gff3Exons.append("%s\t%s\t%s\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], splitM[2], splitM[3], splitM[4], splitM[6], identCurr))
	
	else:
		
		for mIndex, m in enumerate(exons):
			splitM = m.split("\t")
			splitM = list(filter(None, splitM))
			splitM9 = splitM[8].split(";")

			if len(splitM9) > 3:
				identCurr = "%s;%s;%s" %(splitM9[0], splitM9[1], splitM9[2])
				
			else:
				identCurr = splitM9[0]

			bedExons.append("%s\t%s\t%s\t%s %s\t.\t%s"
			%(splitM[0], splitM[3], splitM[4], splitM[2], identCurr, splitM[6]))

			if gffType == "gff-v2":
				gffExons.append("%s\t%s\t%s\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], splitM[2], splitM[3], splitM[4], splitM[6], identCurr))
	
	if len(exons) >= 1:
		exons = []

		if bedOutput == 1:
			writeFile = open(OutFilePrefix+".ExonsOnly.bed", "w+")
			writeFile.write("\n".join(bedExons))
			writeFile.close()
		
		if gffType == "gff-v3" and sameToIutputFile == 1:
			writeFile = open(OutFilePrefix+".ExonsOnly.gff3", "w+")
			writeFile.write("\n".join(gff3Exons))
			writeFile.close()
			gff3Exons = []
			gff3Exons.append("##gff-version 3")
		
		if gffType == "gff-v2" and sameToIutputFile == 1:
			writeFile = open(OutFilePrefix+".ExonsOnly.gtf", "w+")
			writeFile.write("\n".join(gffExons))
			writeFile.close()
			gffExons = []

		if fastaOutput == 1 and fastaSingleInput[0] == 1:
			readFasta(fastaFile=fastaSingleInput[1], bedFile=bedExons, suffix="ExonsOnly")
		
		if fastaOutput == 1 and fastaMultiInput[0] == 1:
			readFasta(fastaFile=multiFastaOutput, bedFile=bedExons, suffix="ExonsOnly")
		
		print("%s Exons extracted successfully from %s" %(datetime.datetime.now(), ".".join(splitFileName[-1].split(".")[:-1])))
	
	bedExons = []
	gff3Exons = []
	gff3Exons.append("##gff-version 3")
	gffExons = []

########################################################################
# transcriptExtraction
########################################################################
def transcriptExtraction(fileName, outputDir, transcript, sameToIutputFile, bedOutput, fastaOutput):
	bedTranscript = []
	gff3Transcript = []
	gff3Transcript.append("##gff-version 3")
	gffTranscript = []

	try:
		splitFileName = fileName.split("/")
		splitFileName = list(filter(None, splitFileName))
		OutFilePrefix = "%s/%s" %(outputDir, splitFileName[-1])
	except ImportError:
		splitFileName = fileName.split("\\")
		splitFileName = list(filter(None, splitFileName))
		OutFilePrefix = "%s\%s" %(outputDir, splitFileName[-1])

	openFile = open(fileName, "r+")
	readFile = openFile.read()
	openFile.close()
	splitFile = readFile.split("\n")
	splitFile = list(filter(None, splitFile))
	readFile = ""

	if splitFile[0] == "##gff-version 3":
		gffType = "gff-v3"

	else:
		gffType = "gff-v2"

	if gffType == "gff-v3":

		for i in splitFile:
			splitI = i.split("\t")
			splitI = list(filter(None, splitI))

			if len(splitI) > 8:
				splitI9 = splitI[8].split(";")

				if splitI[2] in SOFormRNA and "Parent" in splitI[8]:
					transcript.append(i)

	else:

		for i in splitFile:
			splitI = i.split("\t")
			splitI = list(filter(None, splitI))

			if len(splitI) > 8:

				if splitI[2] in SOFormRNA and "transcript_id" in splitI[8]:
					transcript.append(i)
	
	transcript = list(filter(None, transcript))
	splitFile = []

	if gffType == "gff-v3":
		
		for mIndex, m in enumerate(transcript):
			splitM = m.split("\t")
			splitM = list(filter(None, splitM))
			splitM9 = splitM[8].split(";")

			if len(splitM9) > 2:
				identCurr = "%s;%s" %(splitM9[0], splitM9[1])
				
			else:
				identCurr = splitM9[0]
			
			bedTranscript.append("%s\t%s\t%s\t%s %s\t.\t%s"
			%(splitM[0], splitM[3], splitM[4], splitM[2], identCurr, splitM[6]))

			if gffType == "gff-v3":
				gff3Transcript.append("%s\t%s\t%s\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], splitM[2], splitM[3], splitM[4], splitM[6], identCurr))

	else:
		
		for mIndex, m in enumerate(transcript):
			splitM = m.split("\t")
			splitM = list(filter(None, splitM))
			splitM9 = splitM[8].split(";")

			if len(splitM9) > 2:
				identCurr = "%s;%s" %(splitM9[0], splitM9[1])
				
			else:
				identCurr = splitM9[0]

			bedTranscript.append("%s\t%s\t%s\t%s %s\t.\t%s"
			%(splitM[0], splitM[3], splitM[4], splitM[2], identCurr, splitM[6]))
	
			if gffType == "gff-v2":
				gffTranscript.append("%s\t%s\t%s\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], splitM[2], splitM[3], splitM[4], splitM[6], identCurr))

	if len(transcript) >= 1:
		if bedOutput == 1:
			writeFile = open(OutFilePrefix+".TranscriptOnly.bed", "w+")
			writeFile.write("\n".join(bedTranscript))
			writeFile.close()

		if gffType == "gff-v3" and sameToIutputFile == 1:
			writeFile = open(OutFilePrefix+".TranscriptOnly.gff3", "w+")
			writeFile.write("\n".join(gff3Transcript))
			writeFile.close()
			gff3Transcript = []
			gff3Transcript.append("##gff-version 3")
		
		if gffType == "gff-v2" and sameToIutputFile == 1:
			writeFile = open(OutFilePrefix+".TranscriptOnly.gtf", "w+")
			writeFile.write("\n".join(gffTranscript))
			writeFile.close()
			gffTranscript = []

		if fastaOutput == 1 and fastaSingleInput[0] == 1:
			readFasta(fastaFile=fastaSingleInput[1], bedFile=bedTranscript, suffix="TranscriptOnly")

		if fastaOutput == 1 and fastaMultiInput[0] == 1:
			readFasta(fastaFile=multiFastaOutput, bedFile=bedTranscript, suffix="TranscriptOnly")
		
		print("%s Transcripts extracted successfully from %s" %(datetime.datetime.now(), ".".join(splitFileName[-1].split(".")[:-1])))
	
	bedTranscript = []
	gff3Transcript = []
	gff3Transcript.append("##gff-version 3")
	gffTranscript = []

########################################################################
# utr5Extraction
########################################################################
def utr5Extraction(fileName, outputDir, utr5, sameToIutputFile, bedOutput, fastaOutput):
	bedUrt5 = []
	gff3Urt5 = []
	gff3Urt5.append("##gff-version 3")
	gffUrt5 = []

	try:
		splitFileName = fileName.split("/")
		splitFileName = list(filter(None, splitFileName))
		OutFilePrefix = "%s/%s" %(outputDir, splitFileName[-1])
	except ImportError:
		splitFileName = fileName.split("\\")
		splitFileName = list(filter(None, splitFileName))
		OutFilePrefix = "%s\%s" %(outputDir, splitFileName[-1])

	openFile = open(fileName, "r+")
	readFile = openFile.read()
	openFile.close()
	splitFile = readFile.split("\n")
	splitFile = list(filter(None, splitFile))
	readFile = ""

	if splitFile[0] == "##gff-version 3":
		gffType = "gff-v3"

	else:
		gffType = "gff-v2"

	if gffType == "gff-v3":

		for i in splitFile:
			splitI = i.split("\t")
			splitI = list(filter(None, splitI))

			if len(splitI) > 8:
				splitI9 = splitI[8].split(";")

				if "five_prime_utr" in splitI[2] or "five_prime_UTR" in splitI[2]:
					utr5.append(i)

	else:

		for i in splitFile:
			splitI = i.split("\t")
			splitI = list(filter(None, splitI))

			if len(splitI) > 8:

				if "five_prime_utr" in splitI[2] or "five_prime_UTR" in splitI[2]:
					utr5.append(i)

	utr5 = list(filter(None, utr5))
	splitFile = []

	if gffType == "gff-v3":
		
		for mIndex, m in enumerate(utr5):
			splitM = m.split("\t")
			splitM = list(filter(None, splitM))
			splitM9 = splitM[8].split(";")

			if len(splitM9) > 2:
				identCurr = "%s;%s" %(splitM9[0], splitM9[1])
				
			else:
				identCurr = splitM9[0]

			bedUrt5.append("%s\t%s\t%s\t%s %s\t.\t%s"
			%(splitM[0], splitM[3], splitM[4], splitM[2], identCurr, splitM[6]))

			if gffType == "gff-v3":
				gff3Urt5.append("%s\t%s\t%s\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], splitM[2], splitM[3], splitM[4], splitM[6], identCurr))
				
	else:
		
		for mIndex, m in enumerate(utr5):
			splitM = m.split("\t")
			splitM = list(filter(None, splitM))
			splitM9 = splitM[8].split(";")

			if len(splitM9) > 2:
				identCurr = "%s;%s" %(splitM9[0], splitM9[1])
				
			else:
				identCurr = splitM9[0]

			bedUrt5.append("%s\t%s\t%s\t%s %s\t.\t%s"
			%(splitM[0], splitM[3], splitM[4], splitM[2], identCurr, splitM[6]))

			if gffType == "gff-v2":
				gffUrt5.append("%s\t%s\t%s\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], splitM[2], splitM[3], splitM[4], splitM[6], identCurr))

	if len(utr5) >= 1:
		utr5 = []
		if bedOutput == 1:
			writeFile = open(OutFilePrefix+".5UTRsOnly.bed", "w+")
			writeFile.write("\n".join(bedUrt5))
			writeFile.close()
		
		if gffType == "gff-v3" and sameToIutputFile == 1:
			writeFile = open(OutFilePrefix+".5UTRsOnly.gff3", "w+")
			writeFile.write("\n".join(gff3Urt5))
			writeFile.close()
			gff3Urt5 = []
			gff3Urt5.append("##gff-version 3")
		
		if gffType == "gff-v2" and sameToIutputFile == 1:
			writeFile = open(OutFilePrefix+".5UTRsOnly.gtf", "w+")
			writeFile.write("\n".join(gffUrt5))
			writeFile.close()
			gffUrt5 = []

		if fastaOutput == 1 and fastaSingleInput[0] == 1:
			readFasta(fastaFile=fastaSingleInput[1], bedFile=bedUrt5, suffix="5UTRsOnly")
		
		if fastaOutput == 1 and fastaMultiInput[0] == 1:
			readFasta(fastaFile=multiFastaOutput, bedFile=bedUrt5, suffix="5UTRsOnly")
		
		print("%s 5`UTRs extracted successfully from %s" %(datetime.datetime.now(), ".".join(splitFileName[-1].split(".")[:-1])))
	
	bedUrt5 = []
	gff3Urt5 = []
	gff3Urt5.append("##gff-version 3")
	gffUrt5 = []

########################################################################
# utr3Extraction
########################################################################
def utr3Extraction(fileName, outputDir, utr3, sameToIutputFile, bedOutput, fastaOutput):
	bedUrt3 = []
	gff3Urt3 = []
	gff3Urt3.append("##gff-version 3")
	gffUrt3 = []

	try:
		splitFileName = fileName.split("/")
		splitFileName = list(filter(None, splitFileName))
		OutFilePrefix = "%s/%s" %(outputDir, splitFileName[-1])
	except ImportError:
		splitFileName = fileName.split("\\")
		splitFileName = list(filter(None, splitFileName))
		OutFilePrefix = "%s\%s" %(outputDir, splitFileName[-1])

	openFile = open(fileName, "r+")
	readFile = openFile.read()
	openFile.close()
	splitFile = readFile.split("\n")
	splitFile = list(filter(None, splitFile))
	readFile = ""

	if splitFile[0] == "##gff-version 3":
		gffType = "gff-v3"

	else:
		gffType = "gff-v2"

	if gffType == "gff-v3":

		for i in splitFile:
			splitI = i.split("\t")
			splitI = list(filter(None, splitI))

			if len(splitI) > 8:
				splitI9 = splitI[8].split(";")
				
				if "three_prime_UTR" in splitI[2] or "three_prime_utr" in splitI[2]:
					utr3.append(i)

	else:

		for i in splitFile:
			splitI = i.split("\t")
			splitI = list(filter(None, splitI))

			if len(splitI) > 8:

				if "three_prime_UTR" in splitI[2] or "three_prime_utr" in splitI[2]:
					utr3.append(i)
	
	utr3 = list(filter(None, utr3))
	splitFile = []

	if gffType == "gff-v3":
		
		for mIndex, m in enumerate(utr3):
			splitM = m.split("\t")
			splitM = list(filter(None, splitM))
			splitM9 = splitM[8].split(";")

			if len(splitM9) > 2:
				identCurr = "%s;%s" %(splitM9[0], splitM9[1])
				
			else:
				identCurr = splitM9[0]

			bedUrt3.append("%s\t%s\t%s\t%s %s\t.\t%s"
			%(splitM[0], splitM[3], splitM[4], splitM[2], identCurr, splitM[6]))

			if gffType == "gff-v3":
				gff3Urt3.append("%s\t%s\t%s\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], splitM[2], splitM[3], splitM[4], splitM[6], identCurr))

	else:
		
		for mIndex, m in enumerate(utr3):
			splitM = m.split("\t")
			splitM = list(filter(None, splitM))
			splitM9 = splitM[8].split(";")

			if len(splitM9) > 2:
				identCurr = "%s;%s" %(splitM9[0], splitM9[1])
				
			else:
				identCurr = splitM9[0]

			bedUrt3.append("%s\t%s\t%s\t%s %s\t.\t%s"
			%(splitM[0], splitM[3], splitM[4], splitM[2], identCurr, splitM[6]))

			if gffType == "gff-v2":
				gffUrt3.append("%s\t%s\t%s\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], splitM[2], splitM[3], splitM[4], splitM[6], identCurr))
	
	if len(utr3) >= 1:
		utr3 = []
		if bedOutput == 1:
			writeFile = open(OutFilePrefix+".3UTRsOnly.bed", "w+")
			writeFile.write("\n".join(bedUrt3))
			writeFile.close()
		
		if gffType == "gff-v3" and sameToIutputFile == 1:
			writeFile = open(OutFilePrefix+".3UTRsOnly.gff3", "w+")
			writeFile.write("\n".join(gff3Urt3))
			writeFile.close()
			gff3Urt3 = []
			gff3Urt3.append("##gff-version 3")
		
		if gffType == "gff-v2" and sameToIutputFile == 1:
			writeFile = open(OutFilePrefix+".3UTRsOnly.gtf", "w+")
			writeFile.write("\n".join(gffUrt3))
			writeFile.close()
			gffUrt3 = []

		if fastaOutput == 1 and fastaSingleInput[0] == 1:
			readFasta(fastaFile=fastaSingleInput[1], bedFile=bedUrt3, suffix="3UTRsOnly")

		if fastaOutput == 1 and fastaMultiInput[0] == 1:
			readFasta(fastaFile=multiFastaOutput, bedFile=bedUrt3, suffix="3UTRsOnly")
		
		print("%s 3`UTRs extracted successfully from %s" %(datetime.datetime.now(), ".".join(splitFileName[-1].split(".")[:-1])))
	
	bedUrt3 = []
	gff3Urt3 = []
	gff3Urt3.append("##gff-version 3")
	gffUrt3 = []

########################################################################
# cdsExtraction
#########################################################################
def cdsExtraction(fileName, outputDir, cds, sameToIutputFile, bedOutput, fastaOutput):
	bedCDS = []
	gff3CDS = []
	gff3CDS.append("##gff-version 3")
	gffCDS = []

	try:
		splitFileName = fileName.split("/")
		splitFileName = list(filter(None, splitFileName))
		OutFilePrefix = "%s/%s" %(outputDir, splitFileName[-1])
	except ImportError:
		splitFileName = fileName.split("\\")
		splitFileName = list(filter(None, splitFileName))
		OutFilePrefix = "%s\%s" %(outputDir, splitFileName[-1])

	openFile = open(fileName, "r+")
	readFile = openFile.read()
	openFile.close()
	splitFile = readFile.split("\n")
	splitFile = list(filter(None, splitFile))
	readFile = ""

	if splitFile[0] == "##gff-version 3":
		gffType = "gff-v3"

	else:
		gffType = "gff-v2"

	if gffType == "gff-v3":

		for i in splitFile:
			splitI = i.split("\t")
			splitI = list(filter(None, splitI))

			if len(splitI) > 8:
				splitI9 = splitI[8].split(";")

				if "CDS" in splitI[2]:
					cds.append(i)

	else:

		for i in splitFile:
			splitI = i.split("\t")
			splitI = list(filter(None, splitI))

			if len(splitI) > 8:

				if "CDS" in splitI[2]:
					cds.append(i)
	
	cds = list(filter(None, cds))
	splitFile = []

	if gffType == "gff-v3":
		
		for mIndex, m in enumerate(cds):
			splitM = m.split("\t")
			splitM = list(filter(None, splitM))
			splitM9 = splitM[8].split(";")

			if len(splitM9) > 2:
				identCurr = "%s;%s" %(splitM9[0], splitM9[1])
				
			else:
				identCurr = splitM9[0]

			bedCDS.append("%s\t%s\t%s\t%s %s\t.\t%s"
			%(splitM[0], splitM[3], splitM[4], splitM[2], identCurr, splitM[6]))

			if gffType == "gff-v3":
				gff3CDS.append("%s\t%s\t%s\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], splitM[2], splitM[3], splitM[4], splitM[6], identCurr))

	else:
		
		for mIndex, m in enumerate(cds):
			splitM = m.split("\t")
			splitM = list(filter(None, splitM))
			splitM9 = splitM[8].split(";")

			if len(splitM9) > 2:
				identCurr = "%s;%s" %(splitM9[0], splitM9[1])
				
			else:
				identCurr = splitM9[0]

			bedCDS.append("%s\t%s\t%s\t%s %s\t.\t%s"
			%(splitM[0], splitM[3], splitM[4], splitM[2], identCurr, splitM[6]))

			if gffType == "gff-v2":
				gffCDS.append("%s\t%s\t%s\t%s\t%s\t.\t%s\t.\t%s" %(splitM[0], splitM[1], splitM[2], splitM[3], splitM[4], splitM[6], identCurr))

	if len(cds) >= 1:
		cds = []

		if bedOutput == 1:
			writeFile = open(OutFilePrefix+".CDSsOnly.bed", "w+")
			writeFile.write("\n".join(bedCDS))
			writeFile.close()
		
		if gffType == "gff-v3" and sameToIutputFile == 1:
			writeFile = open(OutFilePrefix+".CDSsOnly.gff3", "w+")
			writeFile.write("\n".join(gff3CDS))
			writeFile.close()
			gff3CDS = []
			gff3CDS.append("##gff-version 3")
		
		if gffType == "gff-v2" and sameToIutputFile == 1:
			writeFile = open(OutFilePrefix+".CDSsOnly.gtf", "w+")
			writeFile.write("\n".join(gffCDS))
			writeFile.close()
			gffCDS = []

		if fastaOutput == 1 and fastaSingleInput[0] == 1:
			readFasta(fastaFile=fastaSingleInput[1], bedFile=bedCDS, suffix="CDSsOnly")
		
		if fastaOutput == 1 and fastaMultiInput[0] == 1:
			readFasta(fastaFile=multiFastaOutput, bedFile=bedCDS, suffix="CDSsOnly")
		
		print("%s CDSs extracted successfully from %s" %(datetime.datetime.now(), ".".join(splitFileName[-1].split(".")[:-1])))
	
	bedCDS = []
	gff3CDS = []
	gff3CDS.append("##gff-version 3")
	gffCDS = []

########################################################################
# readFasta
########################################################################
def readFasta(fastaFile, bedFile, suffix):
	fileName = fastaFile
	try:
		splitFastaFileName = fileName.split("/")
		splitFastaFileName = list(filter(None, splitFastaFileName))
		OutFastaFilePrefix = "%s/%s" %(outputDir, splitFastaFileName[-1])
	except ImportError:
		splitFastaFileName = fileName.split("\\")
		splitFastaFileName = list(filter(None, splitFastaFileName))
		OutFastaFilePrefix = "%s\%s" %(outputDir, splitFastaFileName[-1])

	openFile = open(fileName, "r+")
	readFile = openFile.read()
	openFile.close()
	splitFile = readFile.split(">")
	splitFile = list(filter(None, splitFile))
	readFile = ""
	defe = []
	seq = []
	c = 1
	
	for j in splitFile:
		getDeLine = j.split("\n", 1)[0]
		splitJ = getDeLine.split(" ")
		chrID = splitJ[0]
		defe.append(chrID)
		seq.append("".join(j.split("\n", 1)[1:]).replace("\n", "").replace("\r", "").upper())

	splitFile = []
	seq = list(filter(None, seq))
	defe = list(filter(None, defe))
	bedFile = list(filter(None, bedFile))
	fasta = []
	
	for i in bedFile:
		splitI = i.split("\t")
		getChrID = splitI[0]
		if getChrID in defe:
			getIndex = defe.index(getChrID)
			fasta.append(">%s %s %s" %(getChrID, splitI[3], splitI[5]))
			fasta.append(seq[getIndex][int(splitI[1])-1:int(splitI[2])])
	
	seq = []
	defe = []
	writeFile = open(OutFastaFilePrefix+"."+suffix+".fasta", "w+")
	writeFile.write("\n".join(fasta))
	writeFile.close()
	fasta = []

########################################################################
# GUI
########################################################################

def invalidFormat():
	tkMessageBox.showerror("Error", "Invalid file extension")

def warning(message):
	tkMessageBox.showwarning("warning", message)

def infoMessage(message):
	tkMessageBox.showinfo("Information", message)

annoSingleFile = ""
def browseAnnoSingleFile():
	global annoSingleFile
	annoExtension = ["gff3", "gtf", "gff", "gff2"]
	annoSingleFile = ""
	t1.delete(1.0, END)
	annoSingleFile = askopenfilename()
	sAnnoSingleFile = annoSingleFile.split(".")
	sAnnoSingleFile = list(filter(None, sAnnoSingleFile))

	if annoSingleFile and sAnnoSingleFile[-1] in annoExtension:
		t1.insert(INSERT, annoSingleFile)
		c1.configure(state=NORMAL)
		c2.configure(state=NORMAL)
		c3.configure(state=NORMAL)
		c4.configure(state=NORMAL)
		c5.configure(state=NORMAL)
		c6.configure(state=NORMAL)
		c7.configure(state=NORMAL)
		c8.configure(state=NORMAL)
		c9.configure(state=NORMAL)
		c10.configure(state=NORMAL)
		c11.configure(state=NORMAL)
		c12.configure(state=NORMAL)

	else:
		if annoSingleFile:
			invalidFormat()
		c1.configure(state=DISABLED)
		c1.deselect()
		c2.configure(state=DISABLED)
		c2.deselect()
		c3.configure(state=DISABLED)
		c3.deselect()
		c4.configure(state=DISABLED)
		c4.deselect()
		c5.configure(state=DISABLED)
		c5.deselect()
		c6.configure(state=DISABLED)
		c6.deselect()
		c7.configure(state=DISABLED)
		c7.deselect()
		c8.configure(state=DISABLED)
		c8.deselect()
		c9.configure(state=DISABLED)
		c9.deselect()
		c10.configure(state=DISABLED)
		c10.deselect()
		c11.configure(state=DISABLED)
		c11.deselect()
		c12.configure(state=DISABLED)
		c12.deselect()
		c14.configure(state=DISABLED)
		c14.deselect()

fastaSingleFile = ""
def browseFastaSingleFile():
	global fastaSingleFile
	fastaExtensions = ["fna", "fasta", "fn", "fa"]
	fastaSingleFile = ""
	t2.delete(1.0, END)
	fastaSingleFile = askopenfilename()
	sFastaSingleFile = fastaSingleFile.split(".")
	sFastaSingleFile = list(filter(None, sFastaSingleFile))
	
	if fastaSingleFile and sFastaSingleFile[-1] in fastaExtensions:
		t2.insert(INSERT, fastaSingleFile)
		c14.configure(state=NORMAL)
		
	else:
		if fastaSingleFile:
			invalidFormat()
		c14.configure(state=DISABLED)
		c14.deselect()

outputDir = ""
def browseOutputDir():
	global outputDir
	outputDir = ""
	t3.delete(1.0, END)
	outputDir = askdirectory()
	
	if outputDir:
		t3.insert(INSERT, outputDir)

annoMultiFile = ""
collectCorrectAnnoFiles = []
jCollectCorrectAnnoFiles = ""
def browseAnnoMultiFile():
	global annoMultiFile, collectCorrectAnnoFiles, jCollectCorrectAnnoFiles
	annoExtension = ["gff3", "gtf", "gff", "gff2"]
	annoMultiFile = ""
	jCollectCorrectAnnoFiles = ""
	collectCorrectAnnoFiles = []
	t4.delete(1.0, END)
	checkExtension = []
	annoMultiFile = askopenfilenames()
	jAnnoMultiFile = "\n".join(annoMultiFile)

	for i in annoMultiFile:
		splitI = i.split(".")
		splitI = list(filter(None, splitI))
		if splitI[-1] in annoExtension:
			collectCorrectAnnoFiles.append(i)

	jCollectCorrectAnnoFiles = "\n".join(collectCorrectAnnoFiles)

	if collectCorrectAnnoFiles:
		t4.insert(INSERT, jCollectCorrectAnnoFiles)
		infoMessage(message=jCollectCorrectAnnoFiles)
		c1.configure(state=NORMAL)
		c2.configure(state=NORMAL)
		c3.configure(state=NORMAL)
		c4.configure(state=NORMAL)
		c5.configure(state=NORMAL)
		c6.configure(state=NORMAL)
		c7.configure(state=NORMAL)
		c8.configure(state=NORMAL)
		c9.configure(state=NORMAL)
		c10.configure(state=NORMAL)
		c11.configure(state=NORMAL)
		c12.configure(state=NORMAL)

	else:
		if annoMultiFile:
			invalidFormat()
		c1.configure(state=DISABLED)
		c1.deselect()
		c2.configure(state=DISABLED)
		c2.deselect()
		c3.configure(state=DISABLED)
		c3.deselect()
		c4.configure(state=DISABLED)
		c4.deselect()
		c5.configure(state=DISABLED)
		c5.deselect()
		c6.configure(state=DISABLED)
		c6.deselect()
		c7.configure(state=DISABLED)
		c7.deselect()
		c8.configure(state=DISABLED)
		c8.deselect()
		c9.configure(state=DISABLED)
		c9.deselect()
		c10.configure(state=DISABLED)
		c10.deselect()
		c11.configure(state=DISABLED)
		c11.deselect()
		c12.configure(state=DISABLED)
		c12.deselect()
	return annoMultiFile, collectCorrectAnnoFiles, jCollectCorrectAnnoFiles

fastaMultiFile = ""
collectCorrectFastaFiles = []
jCollectCorrectFastaFiles = ""
def browseFastaMultiFile():
	global fastaMultiFile, collectCorrectFastaFiles, jCollectCorrectFastaFiles
	fastaExtensions = ["fna", "fasta", "fn", "fa"]
	fastaMultiFile = ""
	collectCorrectFastaFiles = []
	jCollectCorrectFastaFiles = ""
	t5.delete(1.0, END)
	fastaMultiFile = askopenfilenames()
	jFastaMultiFile = "\n".join(fastaMultiFile)
	checkExtension = []
	
	for i in fastaMultiFile:
		splitI = i.split(".")
		splitI = list(filter(None, splitI))
		if splitI[-1] in fastaExtensions:
			collectCorrectFastaFiles.append(i)
	
	jCollectCorrectFastaFiles = "\n".join(collectCorrectFastaFiles)
	
	if collectCorrectFastaFiles:
		t5.insert(INSERT, jCollectCorrectFastaFiles)
		infoMessage(message=jCollectCorrectFastaFiles)
		c14.configure(state=NORMAL)

	else:
		if fastaMultiFile:
			invalidFormat()
		c14.configure(state=DISABLED)
		c14.deselect()
	return fastaMultiFile, collectCorrectFastaFiles, jCollectCorrectFastaFiles

def activeSingeFile():
	var = v0.get()
	c1.configure(state=DISABLED)
	c1.deselect()
	c1t.configure(state=DISABLED)
	c1c.configure(state=DISABLED)
	c1c.deselect()
	c2t.configure(state=DISABLED)
	c2c.configure(state=DISABLED)
	c2c.deselect()
	c2.configure(state=DISABLED)
	c2.deselect()
	c3.configure(state=DISABLED)
	c3.deselect()
	c4.configure(state=DISABLED)
	c4.deselect()
	c5.configure(state=DISABLED)
	c5.deselect()
	c6.configure(state=DISABLED)
	c6.deselect()
	c7.configure(state=DISABLED)
	c7.deselect()
	c8.configure(state=DISABLED)
	c8.deselect()
	c9.configure(state=DISABLED)
	c9.deselect()
	c10.configure(state=DISABLED)
	c10.deselect()
	c11.configure(state=DISABLED)
	c11.deselect()
	c12.configure(state=DISABLED)
	c12.deselect()
	c14.configure(state=DISABLED)
	c14.deselect()
	
	if var == 1:
		t1.configure(state=NORMAL)
		b1.configure(state=NORMAL)
		t2.configure(state=NORMAL)
		b2.configure(state=NORMAL)
		t4.delete(1.0, END)
		t4.configure(state=DISABLED)
		b4.configure(state=DISABLED)
		t5.delete(1.0, END)
		t5.configure(state=DISABLED)
		b5.configure(state=DISABLED)

	else:
		t1.delete(1.0, END)
		t1.configure(state=DISABLED)
		b1.configure(state=DISABLED)
		t2.delete(1.0, END)
		t2.configure(state=DISABLED)
		b2.configure(state=DISABLED)
		t4.configure(state=NORMAL)
		t5.configure(state=NORMAL)
		b4.configure(state=NORMAL)
		b5.configure(state=NORMAL)

def activeUpstream():
	var = v1.get()
	
	if var == 1:
		c1t.configure(state=NORMAL)
		c1c.configure(state=NORMAL)
	
	else:
		c1t.configure(state=DISABLED)
		c1c.configure(state=DISABLED)
		c1c.deselect()

def activeDownstream():
	var = v2.get()
	
	if var == 1:
		c2t.configure(state=NORMAL)
		c2c.configure(state=NORMAL)
	
	else:
		c2t.configure(state=DISABLED)
		c2c.configure(state=DISABLED)
		c2c.deselect()
inputList = []
singleInput = 0#input(yes=1, no=0)
annoSingleInput = [0, ""]# [input(yes=1, no=0), file name]
fastaSingleInput = [0, ""]# [input(yes=1, no=0), file name]
multiInput = 0#input(yes=1, no=0)
annoMultiInput = [0]# [input(yes=1, no=0), file names]
fastaMultiInput = [0]# [input(yes=1, no=0), file names]
upstreamInput = [0,0,0]# [input(yes=1, no=0), integer(upstram length), forced(yes=1, no=0)]
downstreamInput = [0,0,0]# [input(yes=1, no=0), integer(downstram length), forced(yes=1, no=0)]
geneInput = 0#input(yes=1, no=0)
mrnaInput = 0#input(yes=1, no=0)
utr5Input = 0#input(yes=1, no=0)
utr3Input = 0#input(yes=1, no=0)
exonInput = 0#input(yes=1, no=0)
intronInput = 0#input(yes=1, no=0)
cdsInput = 0#input(yes=1, no=0)
intergenicInput = 0#input(yes=1, no=0)
outputPathInput = ""#directory path
bedInput = 0#input(yes=1, no=0)
sameToInput = 0#input(yes=1, no=0)
fastaInput = 0#input(yes=1, no=0)
runPermission = [0, 0, 0, 0, 0, 0]# [gff(yes=1, no=0), feature(yes=1, no=0), upstream(yes=1, no=0), downstream(yes=1, no=0), output path(yes=1, no=0), output file(yes=1, no=0)]

def checkFields():

	global pairList, inputList, runPermission, singleInput, annoSingleInput, fastaSingleInput, multiInput, annoMultiInput, fastaMultiInput, upstreamInput, downstreamInput, geneInput, mrnaInput, utr5Input, utr3Input, exonInput, intronInput, cdsInput, intergenicInput, outputPathInput, bedInput, sameToInput, fastaInput
	# usr inputs to link "VERY IMPORTANT"
	inputList = []
	singleInput = 0#input(yes=1, no=0)
	annoSingleInput = [0, ""]# [input(yes=1, no=0), file name]
	fastaSingleInput = [0, ""]# [input(yes=1, no=0), file name]
	multiInput = 0#input(yes=1, no=0)
	annoMultiInput = [0]# [input(yes=1, no=0), file names]
	fastaMultiInput = [0]# [input(yes=1, no=0), file names]
	upstreamInput = [0,0,0]# [input(yes=1, no=0), integer(upstram length), forced(yes=1, no=0)]
	downstreamInput = [0,0,0]# [input(yes=1, no=0), integer(downstram length), forced(yes=1, no=0)]
	geneInput = 0#input(yes=1, no=0)
	mrnaInput = 0#input(yes=1, no=0)
	utr5Input = 0#input(yes=1, no=0)
	utr3Input = 0#input(yes=1, no=0)
	exonInput = 0#input(yes=1, no=0)
	intronInput = 0#input(yes=1, no=0)
	cdsInput = 0#input(yes=1, no=0)
	intergenicInput = 0#input(yes=1, no=0)
	outputPathInput = ""#directory path
	bedInput = 0#input(yes=1, no=0)
	sameToInput = 0#input(yes=1, no=0)
	fastaInput = 0#input(yes=1, no=0)
	runPermission = [0, 0, 0, 0, 0, 0]# [gff(yes=1, no=0), feature(yes=1, no=0), upstream(yes=1, no=0), downstream(yes=1, no=0), output path(yes=1, no=0), output file(yes=1, no=0)]

	if v0.get() == 1:
		singleInput = 1

		if annoSingleFile:
			annoSingleInput[0] = 1
			annoSingleInput[1] = annoSingleFile
			runPermission[0] = 1
		else:
			annoSingleInput = []
			warning(message="Select GTF/GFF3 file")
		
		if fastaSingleFile:
			fastaSingleInput[0] = 1
			fastaSingleInput[1] = fastaSingleFile
		
	if v0.get() == 2:
		multiInput = 1
		if collectCorrectAnnoFiles and collectCorrectFastaFiles:
			pairList = []
			unpairedList = []
			for i in collectCorrectAnnoFiles:
				pairedI = ""
				splitI = i.split("/")
				splitLastI = splitI[-1].split(".")
				del splitLastI[-1]
				II = "_".join(splitLastI)
				for j in collectCorrectFastaFiles:
					splitJ = j.split("/")
					splitLastJ = splitJ[-1].split(".")
					del splitLastJ[-1]
					JJ = "_".join(splitLastJ)
					if II == JJ:
						pairedI = "paired"
						pairList.append("%s\t%s" % (i, j))
				if pairedI != "paired":
					unpairedList.append(i)
			if pairList == [] and unpairedList:
				warning(message="Invailed pairing")
			elif unpairedList and pairList:
				lenPaired = len(pairList) * 2
				lenUnpaired = len(unpairedList)
				tkMessageBox.showerror("Error", "Invailed pairing in some files\nPaired:\n%i file(s)\nUnpaired:\n%i file(s)" %(lenPaired, lenUnpaired))
			else:
				runPermission[0] = 1
				annoMultiInput[0] = 2
				fastaMultiInput[0] = 1
				for a in pairList:
					splitA = a.split("\t")
					annoMultiInput.append(splitA[0])
					fastaMultiInput.append(splitA[1])
			
		elif collectCorrectAnnoFiles:
			if not collectCorrectFastaFiles:
				runPermission[0] = 1
				annoMultiInput[0] = 1
				for i in collectCorrectAnnoFiles:
					annoMultiInput.append(i)
		else:
			warning(message="Select GTF/GFF3 file(s)")

	if v1.get() == 1 or v2.get() == 1 or v3.get() == 1 or v4.get() == 1 or v5.get() == 1 or v6.get() == 1 or v7.get() == 1 or v8.get() == 1 or v9.get() == 1 or v10.get() == 1:
		runPermission[1] = 1

		if v1.get() == 1:
			upstreamInput[0] = 1
			if c1t.get():
				runPermission[2] = 1
				upstreamInput[1] = c1t.get()
				if c1v.get() == 1:
					upstreamInput[2] = 1
				else:
					upstreamInput[2] = 0
			else:
				warning(message="Specify upstream length")
		else:
			upstreamInput[0] = 0

		if v2.get() == 1:
			downstreamInput[0] = 1
			if c2t.get():
				runPermission[3] = 1
				downstreamInput[1] = c2t.get()
				if c2v.get() == 1:
					downstreamInput[2] = 1
				else:
					downstreamInput[2] = 0
			else:
				warning(message="Specify downstream length")
		else:
			downstreamInput[0] = 0

		if v3.get() == 1:
			geneInput = 1
		else:
			geneInput = 0
		
		if v4.get() == 1:
			mrnaInput = 1
		else:
			mrnaInput = 0

		if v5.get() == 1:
			utr5Input = 1
		else:
			utr5Input = 0

		if v6.get() == 1:
			utr3Input = 1
		else:
			utr3Input = 0

		if v7.get() == 1:
			exonInput = 1
		else:
			exonInput = 0

		if v8.get() == 1:
			intronInput = 1
		else:
			intronInput = 0

		if v9.get() == 1:
			cdsInput = 1
		else:
			cdsInput = 0

		if v10.get() == 1:
			intergenicInput = 1
		else:
			intergenicInput = 0

	else:
		warning(message="Specify at least 1 feature")

	if outputDir:
		runPermission[4] = 1
		outputPathInput = outputDir
	else:
		warning(message="Select output folder/directory")

	if v11.get() == 1 or v12.get() == 1 or v14.get() == 1:
		runPermission[5] = 1
		if v11.get() == 1:
			bedInput = 1
		else:
			bedInput = 0
		if v12.get() == 1:
			sameToInput = 1
		else:
			sameToInput = 0
		if v14.get() == 1:
			fastaInput = 1
		else:
			fastaInput = 0
	else:
		warning(message="Specify at least 1 output file format")

	inputList = [singleInput, annoSingleInput, fastaSingleInput, multiInput, annoMultiInput, fastaMultiInput, upstreamInput, downstreamInput, geneInput, mrnaInput, utr5Input, utr3Input, exonInput, intronInput, cdsInput, intergenicInput, outputPathInput, bedInput, sameToInput, fastaInput]
	return inputList, runPermission, singleInput, annoSingleInput, fastaSingleInput, multiInput, annoMultiInput, fastaMultiInput, upstreamInput, downstreamInput, geneInput, mrnaInput, utr5Input, utr3Input, exonInput, intronInput, cdsInput, intergenicInput, outputPathInput, bedInput, sameToInput, fastaInput

permissionKey = 0
def permission():
	global permissionKey
	if 0 in runPermission and runPermission[0] != 0 and runPermission[1] != 0 and runPermission[4] != 0 and runPermission[5] != 0:
		if runPermission[2] == 0 and upstreamInput[0] == 0 or runPermission[3] == 0 and downstreamInput[0] == 0:
			permissionKey = 1
	elif 0 not in runPermission:
		permissionKey = 1
	else:
		permissionKey = 0

#inputList = [0"singleInput", 1"annoSingleInput", 2"fastaSingleInput",
#  3"multiInput", 4"annoMultiInput", 5"fastaMultiInput", 
# 6"upstreamInput", 7"downstreamInput", 8"geneInput", 
# 9"mrnaInput", 10"utr5Input", 11"utr3Input", 
# 12"exonInput", 13"intronInput", 14"cdsInput", 
# 15"intergenicInput", 16"outputPathInput", 17"bedInput", 
# 18"sameToInput", 19"fastaInput"]

sameToIutputFile = 0
bedOutput = 0
multiFastaOutput = ""
def runMain():
	global multiFastaOutput
	if permissionKey == 1:
		root.destroy()
		print("%s Submitted successfully" %(datetime.datetime.now()))
		print("%s Please wait..." %(datetime.datetime.now()))
		if inputList[0] == 1:
			getTypes(fileName=inputList[1][1])
			if inputList[6][0] == 1:
				zero()
				upstreamExtraction(fileName=inputList[1][1], outputDir=inputList[16], UpAndDownAndInter=UpAndDownAndInter, upstreamLength=inputList[6][1], status=inputList[6][2],
								sameToIutputFile=inputList[18], bedOutput=inputList[17],
								fastaOutput=inputList[19])
			if inputList[7][0] == 1:
				zero()
				downstreamExtraction(fileName=inputList[1][1], outputDir=inputList[16], UpAndDownAndInter=UpAndDownAndInter, downstreamLength=inputList[7][1], status=inputList[7][2],
								sameToIutputFile=inputList[18], bedOutput=inputList[17],
								fastaOutput=inputList[19])
			if inputList[8] == 1:
				zero()
				genesExtraction(fileName=inputList[1][1], outputDir=inputList[16], UpAndDownAndInter=UpAndDownAndInter, sameToIutputFile=inputList[18],
								bedOutput=inputList[17], fastaOutput=inputList[19])
			if inputList[9] == 1:
				zero()
				transcriptExtraction(fileName=inputList[1][1], outputDir=inputList[16], transcript=transcript,sameToIutputFile=inputList[18],
								bedOutput=inputList[17], fastaOutput=inputList[19])
			if inputList[10] == 1:
				zero()
				utr5Extraction(fileName=inputList[1][1], outputDir=inputList[16], utr5=utr5, sameToIutputFile=inputList[18], bedOutput=inputList[17],
								fastaOutput=inputList[19])
			if inputList[11] == 1:
				zero()
				utr3Extraction(fileName=inputList[1][1], outputDir=inputList[16], utr3=utr3, sameToIutputFile=inputList[18], bedOutput=inputList[17],
								fastaOutput=inputList[19])
			if inputList[12] == 1:
				zero()
				exonsExtraction(fileName=inputList[1][1], outputDir=inputList[16], exons=exons, sameToIutputFile=inputList[18], bedOutput=inputList[17],
								fastaOutput=inputList[19])
			if inputList[13] == 1:
				zero()
				intronsExtraction(fileName=inputList[1][1], outputDir=inputList[16], introns=introns, sameToIutputFile=inputList[18], bedOutput=inputList[17],
								fastaOutput=inputList[19])
			if inputList[14] == 1:
				zero()
				cdsExtraction(fileName=inputList[1][1], outputDir=inputList[16], cds=cds, sameToIutputFile=inputList[18], bedOutput=inputList[17],
								fastaOutput=inputList[19])
			if inputList[15] == 1:
				zero()
				intergenicExtraction(fileName=inputList[1][1], outputDir=inputList[16], UpAndDownAndInter=UpAndDownAndInter, sameToIutputFile=inputList[18],
								bedOutput=inputList[17], fastaOutput=inputList[19])
		
		if inputList[3] == 1:
			if inputList[4][0] == 2:
				for d in pairList:
					splitD = d.split("\t")
					multiFastaOutput = ""
					multiFastaOutput = splitD[1]
					getTypes(fileName=splitD[0])
					zero()
					if inputList[6][0] == 1:
						upstreamExtraction(fileName=splitD[0], outputDir=inputList[16], UpAndDownAndInter=UpAndDownAndInter, upstreamLength=inputList[6][1], status=inputList[6][2],
										sameToIutputFile=inputList[18], bedOutput=inputList[17],
										fastaOutput=inputList[19])
					zero()
					if inputList[7][0] == 1:
						downstreamExtraction(fileName=splitD[0], outputDir=inputList[16], UpAndDownAndInter=UpAndDownAndInter, downstreamLength=inputList[7][1], status=inputList[7][2],
										sameToIutputFile=inputList[18], bedOutput=inputList[17],
										fastaOutput=inputList[19])
					zero()
					if inputList[8] == 1:
						genesExtraction(fileName=splitD[0], outputDir=inputList[16], UpAndDownAndInter=UpAndDownAndInter, sameToIutputFile=inputList[18],
										bedOutput=inputList[17], fastaOutput=inputList[19])
					zero()
					if inputList[9] == 1:
						transcriptExtraction(fileName=splitD[0], outputDir=inputList[16], transcript=transcript,sameToIutputFile=inputList[18],
										bedOutput=inputList[17], fastaOutput=inputList[19])
					zero()
					if inputList[10] == 1:
						utr5Extraction(fileName=splitD[0], outputDir=inputList[16], utr5=utr5, sameToIutputFile=inputList[18], bedOutput=inputList[17],
										fastaOutput=inputList[19])
					zero()
					if inputList[11] == 1:
						utr3Extraction(fileName=splitD[0], outputDir=inputList[16], utr3=utr3, sameToIutputFile=inputList[18], bedOutput=inputList[17],
										fastaOutput=inputList[19])
					zero()
					if inputList[12] == 1:
						exonsExtraction(fileName=splitD[0], outputDir=inputList[16], exons=exons, sameToIutputFile=inputList[18], bedOutput=inputList[17],
										fastaOutput=inputList[19])
					zero()
					if inputList[13] == 1:
						intronsExtraction(fileName=splitD[0], outputDir=inputList[16], introns=introns, sameToIutputFile=inputList[18], bedOutput=inputList[17],
										fastaOutput=inputList[19])
					zero()
					if inputList[14] == 1:
						cdsExtraction(fileName=splitD[0], outputDir=inputList[16], cds=cds, sameToIutputFile=inputList[18], bedOutput=inputList[17],
										fastaOutput=inputList[19])
					zero()
					if inputList[15] == 1:
						intergenicExtraction(fileName=splitD[0], outputDir=inputList[16], UpAndDownAndInter=UpAndDownAndInter, sameToIutputFile=inputList[18],
										bedOutput=inputList[17], fastaOutput=inputList[19])

			elif inputList[4][0] == 1:
				for g in collectCorrectAnnoFiles:
					getTypes(fileName=g)
					zero()
					if inputList[6][0] == 1:
						upstreamExtraction(fileName=g, outputDir=inputList[16], UpAndDownAndInter=UpAndDownAndInter, upstreamLength=inputList[6][1], status=inputList[6][2],
										sameToIutputFile=inputList[18], bedOutput=inputList[17],
										fastaOutput=inputList[19])
					zero()
					if inputList[7][0] == 1:
						downstreamExtraction(fileName=g, outputDir=inputList[16], UpAndDownAndInter=UpAndDownAndInter, downstreamLength=inputList[7][1], status=inputList[7][2],
										sameToIutputFile=inputList[18], bedOutput=inputList[17],
										fastaOutput=inputList[19])
					zero()
					if inputList[8] == 1:
						genesExtraction(fileName=g, outputDir=inputList[16], UpAndDownAndInter=UpAndDownAndInter, sameToIutputFile=inputList[18],
										bedOutput=inputList[17], fastaOutput=inputList[19])
					zero()
					if inputList[9] == 1:
						transcriptExtraction(fileName=g, outputDir=inputList[16], transcript=transcript,sameToIutputFile=inputList[18],
										bedOutput=inputList[17], fastaOutput=inputList[19])
					zero()
					if inputList[10] == 1:
						utr5Extraction(fileName=g, outputDir=inputList[16], utr5=utr5, sameToIutputFile=inputList[18], bedOutput=inputList[17],
										fastaOutput=inputList[19])
					zero()
					if inputList[11] == 1:
						utr3Extraction(fileName=g, outputDir=inputList[16], utr3=utr3, sameToIutputFile=inputList[18], bedOutput=inputList[17],
										fastaOutput=inputList[19])
					zero()
					if inputList[12] == 1:
						exonsExtraction(fileName=g, outputDir=inputList[16], exons=exons, sameToIutputFile=inputList[18], bedOutput=inputList[17],
										fastaOutput=inputList[19])
					zero()
					if inputList[13] == 1:
						intronsExtraction(fileName=g, outputDir=inputList[16], introns=introns, sameToIutputFile=inputList[18], bedOutput=inputList[17],
										fastaOutput=inputList[19])
					zero()
					if inputList[14] == 1:
						cdsExtraction(fileName=g, outputDir=inputList[16], cds=cds, sameToIutputFile=inputList[18], bedOutput=inputList[17],
										fastaOutput=inputList[19])
					zero()
					if inputList[15] == 1:
						intergenicExtraction(fileName=g, outputDir=inputList[16], UpAndDownAndInter=UpAndDownAndInter, sameToIutputFile=inputList[18],
										bedOutput=inputList[17], fastaOutput=inputList[19])
		print("%s Finished successfully" %(datetime.datetime.now()))
		print("Thank You for using GFE")

def Run():
	global permissionKey
	checkFields()
	permission()
	if permissionKey == 1:
		usrInputs = []
		if singleInput != 0:
			usrInputs.append("Input files:")
		if annoSingleInput[0] != 0:
			usrInputs.append("GFF3/GTF file:\n%s" %(annoSingleInput[1]))
		if fastaSingleInput[0] != 0:
			usrInputs.append("FASTA file:\n%s" %(fastaSingleInput[1]))
		if multiInput != 0:
			usrInputs.append("Input files:")
		if annoMultiInput[0] != 0:
			subAnnoMultiInput = annoMultiInput[1:]
			usrInputs.append("GFF3/GTF file(s):\n%s" %("\n".join(subAnnoMultiInput)))
		if fastaMultiInput[0] != 0:
			subFastaMultiInput = fastaMultiInput[1:]
			usrInputs.append("FASTA file(s): \n%s" %("\n".join(subFastaMultiInput)))
		usrInputs.append("\nFeature(s):")
		if upstreamInput[0] != 0:
			if upstreamInput[2] != 0:
				usrInputs.append("Forced %sbp upstream genes" %(str(upstreamInput[1])))
			else:
				usrInputs.append("Flexible %sbp upstream genes" %(str(upstreamInput[1])))
		if downstreamInput[0] != 0:
			if downstreamInput[2] != 0:
				usrInputs.append("Forced %sbp downstream genes" %(str(downstreamInput[1])))
			else:
				usrInputs.append("Flexible %sbp downstream genes" %(str(downstreamInput[1])))
		if geneInput != 0:
			usrInputs.append("Genes")
		if mrnaInput != 0:
			usrInputs.append("mRNAs")
		if utr5Input != 0:
			usrInputs.append("5`UTRs")
		if utr3Input != 0:
			usrInputs.append("3`UTRs")
		if exonInput != 0:
			usrInputs.append("Exons")
		if intronInput != 0:
			usrInputs.append("Introns")
		if cdsInput != 0:
			usrInputs.append("CDSs")
		if intergenicInput != 0:
			usrInputs.append("Intergenic regions")
		if outputPathInput != 0:
			usrInputs.append("\nOutput file/directory:\n%s" %(outputPathInput))
		usrInputs.append("\nOutput file(s):")
		if bedInput != 0:
			usrInputs.append("Bed file")
		if sameToInput != 0:
			usrInputs.append("Same to input file (GFF3/GTF)")
		if fastaInput != 0:
			usrInputs.append("FASTA file")
		if tkMessageBox.askyesno("Submitted", "\n".join(usrInputs)):
			runMain()

logoPath = os.getcwd()
if "/" in logoPath:
	operatingSystem = "L"
else:
	operatingSystem = "W"

#Main window
root = Tk()
root.geometry("1000x650+200+25")
root.resizable(width=False, height=False)
root.title("GAD")
root.config(background="#1e1e1e")

#Logo
if operatingSystem == "L":
	fi = logoPath+"/GAD-Back.gif"
elif operatingSystem == "W":
	fi = logoPath+"\GAD-Back.gif"
photo = PhotoImage()
listDir = os.listdir(logoPath)
if "GAD-Back.gif" in listDir:
	photo.config(file=fi)
	l = Label(root, image=photo, bg="#1e1e1e")
	l.place(x=0,y=0)
else:
	warning(message="Logo image file not in working folder/directory")

#Radiobutton:
v0 = IntVar()
cl1 = Radiobutton(root, text="For single file", variable=v0, value=1, highlightthickness=0, command=activeSingeFile, bg="#1e1e1e", fg="white", selectcolor="#1e1e1e")
cl1.place(x=10, y=150)
cl1.select()
cl2 = Radiobutton(root, text="For multiple files", variable=v0, value=2, highlightthickness=0, command=activeSingeFile, bg="#1e1e1e", fg="white", selectcolor="#1e1e1e")
cl2.place(x=510, y=150)

#Frame one: Inputs
lf1 = Label(root, text="Input(s)", bg="#1e1e1e", fg="white")
lf1.place(x=10, y=180)
f1 = Frame(root, bg="#333333", width=480, height=120)
f1.place(x=10, y=200)
l1 = Label(f1, text="Select GTF/GFF3 file", bg="#333333", fg="white")
l1.place(x=10, y=10)
t1 = Text(f1, width=40, height=1, highlightthickness=0)
t1.place(x=10, y=30)
b1 = Button(f1, text="Browse", command=browseAnnoSingleFile, activebackground="white", activeforeground="black", highlightthickness=0, bg="#0e639c", fg="white")
b1.place(x=375, y=25)
l2 = Label(f1, text="Select FASTA file", bg="#333333", fg="white")
l2.place(x=10, y=60)
t2 = Text(f1, width=40, height=1, highlightthickness=0)
t2.place(x=10, y=80)
b2 = Button(f1, text="Browse", command=browseFastaSingleFile, activebackground="white", activeforeground="black", highlightthickness=0, bg="#0e639c", fg="white")
b2.place(x=375, y=75)

#Frame two: Select feature(s)
lf2 = Label(root, text="Select feature(s)", bg="#1e1e1e", fg="white")
lf2.place(x=10, y=330)
f2 = Frame(root, bg="#333333", width=980, height=100)
f2.place(x=10, y=350)
v1 = IntVar()
c1 = Checkbutton(f2, text="Upstream Genes", variable=v1, state=DISABLED, highlightthickness=0, command=activeUpstream, bg="#333333", fg="white", selectcolor="#333333")
c1.place(x=10, y=10)
c1t = Entry(f2, width=20, state=DISABLED, highlightthickness=0)
c1t.place(x=200, y=10)
c1v = IntVar()
c1c = Checkbutton(f2, text="Fixed", variable=c1v, highlightthickness=0, state=DISABLED, bg="#333333", fg="white", selectcolor="#333333")
c1c.place(x=400, y=10)
v2 = IntVar()
c2 = Checkbutton(f2, text="Downstream Genes", variable=v2, state=DISABLED, highlightthickness=0, command=activeDownstream, bg="#333333", fg="white", selectcolor="#333333")
c2.place(x=10, y=40)
c2t = Entry(f2, width=20, state=DISABLED, highlightthickness=0)
c2t.place(x=200, y=40)
c2v = IntVar()
c2c = Checkbutton(f2, text="Fixed", variable=c2v, highlightthickness=0, state=DISABLED, bg="#333333", fg="white", selectcolor="#333333")
c2c.place(x=400, y=40)
v3 = IntVar()
c3 = Checkbutton(f2, text="Genes", variable=v3, state=DISABLED, highlightthickness=0, bg="#333333", fg="white", selectcolor="#333333")
c3.place(x=130, y=70)
v4 = IntVar()
c4 = Checkbutton(f2, text="Transcripts", variable=v4, state=DISABLED, highlightthickness=0, bg="#333333", fg="white", selectcolor="#333333")
c4.place(x=250, y=70)
v5 = IntVar()
c5 = Checkbutton(f2, text="5`UTRs", variable=v5, state=DISABLED, highlightthickness=0, bg="#333333", fg="white", selectcolor="#333333")
c5.place(x=370, y=70)
v6 = IntVar()
c6 = Checkbutton(f2, text="3`UTRs", variable=v6, state=DISABLED, highlightthickness=0, bg="#333333", fg="white", selectcolor="#333333")
c6.place(x=490, y=70)
v7 = IntVar()
c7 = Checkbutton(f2, text="Exons", variable=v7, state=DISABLED, highlightthickness=0, bg="#333333", fg="white", selectcolor="#333333")
c7.place(x=610, y=70)
v8 = IntVar()
c8 = Checkbutton(f2, text="Introns", variable=v8, state=DISABLED, highlightthickness=0, bg="#333333", fg="white", selectcolor="#333333")
c8.place(x=730, y=70)
v9 = IntVar()
c9 = Checkbutton(f2, text="CDSs", variable=v9, state=DISABLED, highlightthickness=0, bg="#333333", fg="white", selectcolor="#333333")#command=CDSFeatures
c9.place(x=850, y=70)
v10 = IntVar()
c10 = Checkbutton(f2, text="Intergenic", variable=v10, state=DISABLED, highlightthickness=0, bg="#333333", fg="white", selectcolor="#333333")#command=CDSFeatures
c10.place(x=10, y=70)

#Frame three: Outputs
lf3 = Label(root, text="Output(s)", bg="#1e1e1e", fg="white")
lf3.place(x=10, y=460)
f3 = Frame(root, bg="#333333", width=980, height=110)
f3.place(x=10, y=480)
l3 = Label(f3, text="Select output path", bg="#333333", fg="white")
l3.place(x=10, y=10)
t3 = Text(f3, width=40, height=1, highlightthickness=0)
t3.place(x=10, y=30)
b3 = Button(f3, text="Browse", command=browseOutputDir, height=1, activebackground="white", activeforeground="black", highlightthickness=0, bg="#0e639c", fg="white")
b3.place(x=375, y=25)
l4 = Label(f3, text="Select output format(s)", bg="#333333", fg="white")
l4.place(x=10, y=60)
v11 = IntVar()
c11 = Checkbutton(f3, text="Bed file format", variable=v11, highlightthickness=0, state=DISABLED, bg="#333333", fg="white", selectcolor="#333333")
c11.place(x=330, y=80)
v12 = IntVar()
c12 = Checkbutton(f3, text="Same to input file format (GFF3/GTF)", variable=v12, highlightthickness=0, state=DISABLED, bg="#333333", fg="white", selectcolor="#333333")
c12.place(x=650, y=80)
v14 = IntVar()
c14 = Checkbutton(f3, text="FASTA file format", variable=v14, highlightthickness=0, state=DISABLED, bg="#333333", fg="white", selectcolor="#333333")
c14.place(x=10, y=80)

#Frame four: Inputs
lf4 = Label(root, text="Input(s)", bg="#1e1e1e", fg="white")
lf4.place(x=510, y=180)
f4 = Frame(root, bg="#333333", width=480, height=120)
f4.place(x=510, y=200)
l4 = Label(f4, text="Select text file contains GTF/GFF3 file name(s)", bg="#333333", fg="white")
l4.place(x=10, y=10)
t4 = Text(f4, width=40, height=1, highlightthickness=0, state=DISABLED)
t4.place(x=10, y=30)
b4 = Button(f4, text="Browse", command=browseAnnoMultiFile, state=DISABLED, activebackground="white", activeforeground="black", highlightthickness=0, bg="#0e639c", fg="white")
b4.place(x=375, y=25)
l5 = Label(f4, text="Select text file contains FASTA file name(s)", bg="#333333", fg="white")
l5.place(x=10, y=60)
t5 = Text(f4, width=40, height=1, highlightthickness=0, state=DISABLED)
t5.place(x=10, y=80)
b5 = Button(f4, text="Browse", command=browseFastaMultiFile, state=DISABLED, activebackground="white", activeforeground="black", highlightthickness=0, bg="#0e639c", fg="white")
b5.place(x=375, y=75)

#Footer label:
ll = Label(root, text="Developed by Norhan Yasser & Ahmed Karam", bg="#68217a", fg="white", width=300, anchor=S+W)
ll.pack(side=BOTTOM)

#Run button
b6 = Button(root, text="Run", command=Run, width=6, height=1, activebackground="white", activeforeground="black", highlightthickness=0, bg="#0e639c", fg="white")
b6.place(x=500, y=610, anchor=CENTER)

root.mainloop()
